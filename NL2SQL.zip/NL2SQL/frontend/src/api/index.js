import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 60000,
})

export default {
  // 自然语言转SQL
  convert(data) {
    return api.post('/convert', data)
  },

  // 获取数据字典
  getSchemas() {
    return api.get('/schemas')
  },

  // 获取支持的方言
  getDialects() {
    return api.get('/dialects')
  },

  // 获取LLM提供者
  getProviders() {
    return api.get('/providers')
  },

  // 获取配置
  getConfig() {
    return api.get('/config')
  },

  // 获取历史记录
  getHistory() {
    return api.get('/history')
  },

  // 健康检查
  health() {
    return api.get('/health')
  },

  // 更新 API Key
  updateApiKey(provider, apiKey) {
    return api.post('/config/api-key', { provider, api_key: apiKey })
  },

  // 验证 SQL 语法
  validateSql(sql, dialect = 'hive') {
    return api.post('/validate-sql', { sql, dialect })
  },

  // 转换 SQL 方言
  convertSql(sql, dialect) {
    return api.post('/convert-sql', { sql, dialect })
  },
}