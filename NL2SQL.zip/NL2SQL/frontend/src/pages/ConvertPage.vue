<template>
  <div class="convert-page">
    <el-card class="config-card">
      <template #header>
        <div class="card-header">
          <span><el-icon><Setting /></el-icon> 转换配置</span>
        </div>
      </template>
      <el-form :inline="true" :model="form" class="config-form">
        <el-form-item label="运行模式">
          <el-select v-model="form.mode" placeholder="选择模式" style="width: 120px">
            <el-option label="混合模式" value="hybrid" />
            <el-option label="规则引擎" value="rule" />
            <el-option label="大模型" value="llm" />
          </el-select>
        </el-form-item>

        <el-form-item label="LLM提供者" v-if="form.mode !== 'rule'">
          <el-select v-model="form.provider" placeholder="选择提供者" style="width: 140px">
            <el-option
              v-for="p in providers"
              :key="p.id"
              :label="p.name"
              :value="p.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="模型" v-if="form.mode !== 'rule'">
          <el-select v-model="form.model" placeholder="选择模型" style="width: 160px">
            <el-option
              v-for="m in currentModels"
              :key="m"
              :label="m"
              :value="m"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="SQL方言">
          <el-select v-model="form.dialect" placeholder="选择方言" style="width: 140px">
            <el-option
              v-for="d in dialects"
              :key="d.id"
              :label="d.name"
              :value="d.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="使用本地Schema" v-if="form.mode !== 'rule'">
          <el-switch
            v-model="form.use_schema"
            active-text="参考"
            inactive-text="自由"
            inline-prompt
            style="--el-switch-on-color: #409EFF; --el-switch-off-color: #67C23A"
          />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleConvert" :loading="loading">
            <el-icon><Edit /></el-icon>
            转换
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <div class="main-content">
      <el-row :gutter="20">
        <el-col :span="12">
          <el-card class="input-card">
            <template #header>
              <div class="card-header">
                <span><el-icon><ChatDotRound /></el-icon> 自然语言输入</span>
                <el-button text @click="clearInput">清空</el-button>
              </div>
            </template>
            <el-input
              v-model="inputText"
              type="textarea"
              :rows="8"
              placeholder="请输入自然语言查询，例如：最近7天华北地区每天的销售额"
              @keydown.enter.ctrl="handleConvert"
            />
            <div class="input-tips">
              <el-text type="info" size="small">
                提示：按 Ctrl + Enter 快速转换
              </el-text>
            </div>
          </el-card>
        </el-col>

        <el-col :span="12">
          <el-card class="output-card">
            <template #header>
              <div class="card-header">
                <span><el-icon><Document /></el-icon> SQL输出</span>
                <div>
                  <el-button
                    text
                    @click="copySql"
                    :disabled="!result.sql"
                  >
                    <el-icon><CopyDocument /></el-icon> 复制
                  </el-button>
                  <el-button text @click="formatSql" :disabled="!result.sql">
                    <el-icon><MagicStick /></el-icon> 格式化
                  </el-button>
                  <el-button text @click="validateSql" :disabled="!result.sql" :type="validationStatus.type">
                    <el-icon><CircleCheck /></el-icon> 验证
                  </el-button>
                </div>
              </div>
            </template>
            <div class="sql-output">
              <pre v-if="result.sql">{{ result.sql }}</pre>
              <el-empty v-else description="等待转换..." />
            </div>
          </el-card>
        </el-col>
      </el-row>

      <el-card class="result-info" v-if="result.sql">
        <el-descriptions :column="4" border>
          <el-descriptions-item label="来源">
            <el-tag :type="result.source === 'llm' ? 'primary' : 'success'">
              {{ result.source === 'llm' ? '大模型' : '规则引擎' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="置信度">
            <el-progress
              :percentage="Math.round(result.confidence * 100)"
              :color="getConfidenceColor(result.confidence)"
              style="width: 100px"
            />
          </el-descriptions-item>
          <el-descriptions-item label="耗时">
            {{ result.elapsed_ms }} ms
          </el-descriptions-item>
          <el-descriptions-item label="方言">
            {{ result.dialect }}
          </el-descriptions-item>
          <el-descriptions-item label="语法验证">
            <el-tag v-if="validationStatus.validated" :type="validationStatus.type" size="small">
              {{ validationStatus.type === 'success' ? '通过' : '失败' }}
            </el-tag>
            <el-tag v-else type="info" size="small">未验证</el-tag>
          </el-descriptions-item>
        </el-descriptions>
      </el-card>

      <el-card class="ir-card" v-if="showIr && result.ir">
        <template #header>
          <div class="card-header">
            <span><el-icon><Guide /></el-icon> 中间表示 (IR)</span>
            <el-button text @click="showIr = false">收起</el-button>
          </div>
        </template>
        <pre class="json-output">{{ JSON.stringify(result.ir, null, 2) }}</pre>
      </el-card>
    </div>

    <el-card class="history-card" v-if="localHistory.length > 0">
      <template #header>
        <div class="card-header">
          <span><el-icon><Clock /></el-icon> 本次会话历史</span>
          <el-button text @click="clearHistory">清空历史</el-button>
        </div>
      </template>
      <el-table :data="localHistory" style="width: 100%" max-height="200">
        <el-table-column prop="input" label="输入" width="300" show-overflow-tooltip />
        <el-table-column prop="sql" label="SQL" min-width="200" show-overflow-tooltip />
        <el-table-column prop="source" label="来源" width="80">
          <template #default="{ row }">
            <el-tag size="small" :type="row.source === 'llm' ? 'primary' : 'success'">
              {{ row.source === 'llm' ? 'LLM' : '规则' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="dialect" label="方言" width="100" />
        <el-table-column label="操作" width="120">
          <template #default="{ row }">
            <el-button link type="primary" @click="restoreHistory(row)">恢复</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ChatDotRound, CopyDocument, MagicStick, Guide, CircleCheck } from '@element-plus/icons-vue'
import api from '@/api'

const inputText = ref('')
const loading = ref(false)
const showIr = ref(false)
const dialects = ref([])
const providers = ref([])

const form = reactive({
  mode: 'hybrid',
  provider: 'deepseek',
  model: 'deepseek-v4-flash',
  dialect: 'hive',
  use_schema: true,
})

const result = reactive({
  sql: '',
  source: '',
  confidence: 0,
  elapsed_ms: 0,
  dialect: '',
  ir: {},
  error: '',
})

const localHistory = ref(JSON.parse(localStorage.getItem('nl2sql_history') || '[]'))

const saveHistory = () => {
  localStorage.setItem('nl2sql_history', JSON.stringify(localHistory.value))
}

const validationStatus = reactive({
  type: 'info',
  message: '',
  validated: false,
})

const currentModels = computed(() => {
  const p = providers.value.find(p => p.id === form.provider)
  return p ? p.models : []
})

onMounted(async () => {
  try {
    const [dialectRes, providerRes] = await Promise.all([
      api.getDialects(),
      api.getProviders(),
    ])
    dialects.value = dialectRes.data.dialects
    providers.value = providerRes.data.providers
    if (providers.value.length > 0) {
      const p = providers.value.find(p => p.id === form.provider)
      if (p && p.models.length > 0) {
        form.model = p.models[0]
      }
    }
  } catch (error) {
    ElMessage.error('加载配置失败，请检查API服务是否运行')
  }
})

watch(() => form.provider, (newProvider) => {
  const p = providers.value.find(p => p.id === newProvider)
  if (p && p.models.length > 0) {
    form.model = p.models[0]
  }
})

const handleConvert = async () => {
  if (!inputText.value.trim()) {
    ElMessage.warning('请输入查询内容')
    return
  }

  loading.value = true
  try {
    const response = await api.convert({
      text: inputText.value,
      mode: form.mode,
      provider: form.provider,
      model: form.model || undefined,
      dialect: form.dialect,
      temperature: 0.1,
      use_schema: form.use_schema,
    })

    Object.assign(result, response.data)

    localHistory.value.unshift({
      input: inputText.value,
      sql: response.data.sql,
      source: response.data.source,
      dialect: response.data.dialect,
      confidence: response.data.confidence || 0,
      config: { ...form },
    })

    if (localHistory.value.length > 10) {
      localHistory.value = localHistory.value.slice(0, 10)
    }

    saveHistory()
    showIr.value = true
  } catch (error) {
    ElMessage.error(error.response?.data?.detail || '转换失败')
  } finally {
    loading.value = false
  }
}

const clearInput = () => {
  inputText.value = ''
  result.sql = ''
}

const clearHistory = () => {
  localHistory.value = []
  saveHistory()
}

const restoreHistory = (row) => {
  inputText.value = row.input
  Object.assign(form, row.config)
}

const copySql = async () => {
  try {
    await navigator.clipboard.writeText(result.sql)
    ElMessage.success('SQL已复制到剪贴板')
  } catch {
    ElMessage.error('复制失败')
  }
}

const formatSql = () => {
  let sql = result.sql
  sql = sql.replace(/SELECT/gi, 'SELECT\n  ')
  sql = sql.replace(/FROM/gi, '\nFROM')
  sql = sql.replace(/WHERE/gi, '\nWHERE\n  ')
  sql = sql.replace(/AND/gi, '\n  AND')
  sql = sql.replace(/GROUP BY/gi, '\nGROUP BY\n  ')
  sql = sql.replace(/ORDER BY/gi, '\nORDER BY\n  ')
  sql = sql.replace(/LIMIT/gi, '\nLIMIT')
  result.sql = sql
}

const getConfidenceColor = (value) => {
  if (value >= 0.8) return '#67c23a'
  if (value >= 0.6) return '#e6a23c'
  return '#f56c6c'
}

const validateSql = async () => {
  if (!result.sql) return

  try {
    const response = await api.validateSql(result.sql, result.dialect)
    if (response.data.valid) {
      validationStatus.type = 'success'
      validationStatus.message = 'SQL 语法正确'
      validationStatus.validated = true
      ElMessage.success('SQL 语法验证通过')

      if (response.data.sql && response.data.sql !== result.sql) {
        result.sql = response.data.sql
      }
    } else {
      validationStatus.type = 'danger'
      validationStatus.message = response.data.error
      validationStatus.validated = false
      ElMessage.error('SQL 语法错误: ' + response.data.error)
    }
  } catch (error) {
    validationStatus.type = 'danger'
    validationStatus.message = '验证失败'
    validationStatus.validated = false
    ElMessage.error('验证失败')
  }
}
</script>

<style scoped>
.convert-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.config-card {
  flex-shrink: 0;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-header span {
  display: flex;
  align-items: center;
  gap: 8px;
}

.config-form {
  margin-bottom: 0;
}

.main-content {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.input-card,
.output-card {
  height: 100%;
}

.input-tips {
  margin-top: 10px;
  text-align: right;
}

.sql-output {
  min-height: 180px;
  max-height: 400px;
  overflow-y: auto;
}

.sql-output pre {
  margin: 0;
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 13px;
  line-height: 1.5;
  white-space: pre-wrap;
  word-break: break-all;
}

.result-info {
  flex-shrink: 0;
}

.ir-card {
  flex-shrink: 0;
}

.json-output {
  margin: 0;
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 12px;
  line-height: 1.5;
  background-color: #f5f7fa;
  padding: 15px;
  border-radius: 4px;
  max-height: 300px;
  overflow-y: auto;
}

.history-card {
  flex-shrink: 0;
}
</style>