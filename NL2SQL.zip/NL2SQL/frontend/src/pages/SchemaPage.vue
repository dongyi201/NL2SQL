<template>
  <div class="schema-page">
    <el-card>
      <template #header>
        <div class="card-header">
          <span><el-icon><Document /></el-icon> 数据字典</span>
          <div class="header-actions">
            <el-button size="small" @click="expandedTables = schemaData.tables.map(t => t.name)">
              展开全部
            </el-button>
            <el-button size="small" @click="expandedTables = []">
              折叠全部
            </el-button>
            <el-input
              v-model="searchKeyword"
              placeholder="搜索表名或字段..."
              style="width: 200px"
              clearable
            >
              <template #prefix>
                <el-icon><Search /></el-icon>
              </template>
            </el-input>
          </div>
        </div>
      </template>

      <el-tabs v-model="activeTab" type="border-card">
        <el-tab-pane label="数据表" name="tables">
          <div class="pagination-info" v-if="pagedTables.length > 0">
            共 {{ filteredTables.length }} 张表，当前显示第 {{ (currentPage - 1) * pageSize + 1 }}-{{ Math.min(currentPage * pageSize, filteredTables.length) }} 条
          </div>
          <el-collapse v-model="expandedTables">
            <el-collapse-item
              v-for="table in pagedTables"
              :key="table.name"
              :title="`${table.name} (${table.chinese_name})`"
              :name="table.name"
            >
              <template #title>
                <div class="table-title">
                  <el-icon><Grid /></el-icon>
                  <span class="table-name">{{ table.name }}</span>
                  <el-tag size="small" type="info">{{ table.chinese_name }}</el-tag>
                </div>
              </template>

              <div class="table-description" v-if="table.description">
                <el-text type="info">{{ table.description }}</el-text>
              </div>

              <el-table :data="table.columns" border style="margin-top: 10px">
                <el-table-column prop="name" label="字段名" width="180">
                  <template #default="{ row }">
                    <el-tag size="small" type="primary">{{ row.name }}</el-tag>
                  </template>
                </el-table-column>
                <el-table-column prop="chinese_name" label="中文名" width="120" />
                <el-table-column prop="type" label="类型" width="120">
                  <template #default="{ row }">
                    <el-tag size="small">{{ row.type }}</el-tag>
                  </template>
                </el-table-column>
                <el-table-column prop="aliases" label="别名" min-width="200">
                  <template #default="{ row }">
                    <el-tag
                      v-for="alias in row.aliases"
                      :key="alias"
                      size="small"
                      style="margin-right: 5px"
                    >
                      {{ alias }}
                    </el-tag>
                    <span v-if="!row.aliases || row.aliases.length === 0">-</span>
                  </template>
                </el-table-column>
                <el-table-column prop="enum_values" label="枚举值" min-width="150">
                  <template #default="{ row }">
                    <el-tag
                      v-for="val in row.enum_values"
                      :key="val"
                      size="small"
                      type="success"
                      style="margin-right: 5px"
                    >
                      {{ val }}
                    </el-tag>
                    <span v-if="!row.enum_values || row.enum_values.length === 0">-</span>
                  </template>
                </el-table-column>
              </el-table>
            </el-collapse-item>
          </el-collapse>

          <div class="pagination-container" v-if="filteredTables.length > pageSize">
            <el-pagination
              v-model:current-page="currentPage"
              v-model:page-size="pageSize"
              :page-sizes="[10, 20, 50]"
              :total="filteredTables.length"
              layout="total, sizes, prev, pager, next, jumper"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
            />
          </div>
        </el-tab-pane>

        <el-tab-pane label="同义词映射" name="synonyms">
          <el-table :data="synonymList" border>
            <el-table-column prop="keyword" label="关键词" width="200">
              <template #default="{ row }">
                <el-tag size="small" type="primary">{{ row.keyword }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="expression" label="对应表达式">
              <template #default="{ row }">
                <code class="expression-code">{{ row.expression }}</code>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="表关联关系" name="relations">
          <div class="pagination-info" v-if="schemaData.relations.length > 0">
            共 {{ schemaData.relations.length }} 条关联关系
          </div>
          <el-table :data="schemaData.relations" border>
            <el-table-column prop="from_table" label="源表" width="250">
              <template #default="{ row }">
                <el-tag size="small" type="primary">{{ row.from_table }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="关系" width="80">
              <template #default="{ row }">
                <el-icon><ArrowRight /></el-icon>
              </template>
            </el-table-column>
            <el-table-column prop="to_table" label="目标表" width="250">
              <template #default="{ row }">
                <el-tag size="small" type="success">{{ row.to_table }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="relation_type" label="关系类型" width="100">
              <template #default="{ row }">
                <el-tag size="small" type="info">{{ row.relation_type }}</el-tag>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Search, Grid, Tickets, Connection, ArrowRight } from '@element-plus/icons-vue'
import api from '@/api'

const schemaData = ref({
  tables: [],
  relations: [],
  synonym_map: {},
})

const searchKeyword = ref('')
const activeTab = ref('tables')
const expandedTables = ref([])

const currentPage = ref(1)
const pageSize = ref(10)

const filteredTables = computed(() => {
  currentPage.value = 1
  if (!searchKeyword.value) {
    return schemaData.value.tables
  }
  const keyword = searchKeyword.value.toLowerCase()
  return schemaData.value.tables.filter(table => {
    if (table.name.toLowerCase().includes(keyword) ||
        table.chinese_name.toLowerCase().includes(keyword)) {
      return true
    }
    return table.columns.some(col =>
      col.name.toLowerCase().includes(keyword) ||
      col.chinese_name.toLowerCase().includes(keyword) ||
      col.aliases?.some(alias => alias.toLowerCase().includes(keyword))
    )
  })
})

const pagedTables = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  return filteredTables.value.slice(start, end)
})

const synonymList = computed(() => {
  return Object.entries(schemaData.value.synonym_map || {}).map(([keyword, expression]) => ({
    keyword,
    expression,
  }))
})

const handleSizeChange = (val) => {
  pageSize.value = val
  currentPage.value = 1
}

const handleCurrentChange = (val) => {
  currentPage.value = val
}

const handleTableExpand = (tableName) => {
  const index = expandedTables.value.indexOf(tableName)
  if (index > -1) {
    expandedTables.value.splice(index, 1)
  } else {
    expandedTables.value.push(tableName)
  }
}

onMounted(async () => {
  try {
    const response = await api.getSchemas()
    schemaData.value = response.data
    expandedTables.value = []
  } catch (error) {
    ElMessage.error('加载数据字典失败')
  }
})
</script>

<style scoped>
.schema-page {
  height: 100%;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.table-title {
  display: flex;
  align-items: center;
  gap: 10px;
}

.table-name {
  font-weight: bold;
  color: #409eff;
}

.table-description {
  margin-bottom: 10px;
  padding: 8px;
  background-color: #f5f7fa;
  border-radius: 4px;
}

.pagination-info {
  padding: 8px 0;
  font-size: 13px;
  color: #606266;
}

.pagination-container {
  display: flex;
  justify-content: center;
  padding: 20px 0;
}

.expression-code {
  font-family: 'Consolas', 'Monaco', monospace;
  background-color: #f5f7fa;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 13px;
}

:deep(.el-collapse-item__header) {
  font-size: 14px;
}

:deep(.el-table) {
  font-size: 13px;
}

:deep(.el-tag) {
  font-size: 12px;
}
</style>