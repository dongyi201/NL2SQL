<template>
  <div class="history-page">
    <el-card>
      <template #header>
        <div class="card-header">
          <span><el-icon><Clock /></el-icon> 历史记录</span>
          <el-button text @click="clearHistory">
            <el-icon><Delete /></el-icon> 清空
          </el-button>
        </div>
      </template>

      <el-empty v-if="history.length === 0" description="暂无历史记录" />

      <el-table v-else :data="history" border style="width: 100%">
        <el-table-column type="index" label="序号" width="60" />
        <el-table-column prop="input" label="输入" min-width="200" show-overflow-tooltip />
        <el-table-column prop="sql" label="生成的SQL" min-width="250" show-overflow-tooltip>
          <template #default="{ row }">
            <code class="sql-code">{{ row.sql }}</code>
          </template>
        </el-table-column>
        <el-table-column prop="source" label="来源" width="80">
          <template #default="{ row }">
            <el-tag size="small" :type="row.source === 'llm' ? 'primary' : 'success'">
              {{ row.source === 'llm' ? 'LLM' : '规则' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="dialect" label="方言" width="100" />
        <el-table-column prop="confidence" label="置信度" width="100">
          <template #default="{ row }">
            <el-progress
              :percentage="Math.round(row.confidence * 100)"
              :color="getConfidenceColor(row.confidence)"
              style="width: 80px"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120">
          <template #default="{ row }">
            <el-button link type="primary" @click="restoreQuery(row)">
              恢复
            </el-button>
            <el-button link type="danger" @click="deleteItem(row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useRouter } from 'vue-router'

const router = useRouter()
const history = ref([])

const loadHistory = () => {
  history.value = JSON.parse(localStorage.getItem('nl2sql_history') || '[]')
}

const saveHistory = () => {
  localStorage.setItem('nl2sql_history', JSON.stringify(history.value))
}

onMounted(() => {
  loadHistory()
})

const clearHistory = async () => {
  try {
    await ElMessageBox.confirm('确定要清空所有历史记录吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    })
    history.value = []
    saveHistory()
    ElMessage.success('历史记录已清空')
  } catch {
    // 用户取消
  }
}

const restoreQuery = (row) => {
  router.push({ path: '/convert' })
}

const deleteItem = (row) => {
  const index = history.value.indexOf(row)
  if (index > -1) {
    history.value.splice(index, 1)
    saveHistory()
    ElMessage.success('已删除')
  }
}

const getConfidenceColor = (value) => {
  if (value >= 0.8) return '#67c23a'
  if (value >= 0.6) return '#e6a23c'
  return '#f56c6c'
}
</script>

<style scoped>
.history-page {
  height: 100%;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.sql-code {
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 12px;
  background-color: #f5f7fa;
  padding: 2px 6px;
  border-radius: 3px;
}
</style>