<template>
  <div class="config-page">
    <el-card>
      <template #header>
        <span><el-icon><Setting /></el-icon> 系统配置</span>
      </template>

      <el-tabs v-model="activeTab" type="border-card">
        <el-tab-pane label="LLM配置" name="llm">
          <el-form label-width="140px">
            <el-form-item label="默认提供者">
              <el-select v-model="config.default_provider" style="width: 200px">
                <el-option
                  v-for="p in config.providers"
                  :key="p.id"
                  :label="p.display_name"
                  :value="p.id"
                />
              </el-select>
            </el-form-item>

            <el-divider content-position="left">API Key 配置</el-divider>

            <el-form-item label="选择提供者">
              <el-select v-model="selectedProvider" placeholder="选择要配置Key的提供者" style="width: 200px" @change="onProviderChange">
                <el-option
                  v-for="p in availableProviders"
                  :key="p.id"
                  :label="p.name"
                  :value="p.id"
                />
              </el-select>
            </el-form-item>

            <el-form-item label="API Key">
              <el-input
                v-model="apiKeyInput"
                :placeholder="selectedProvider ? '请输入 ' + selectedProviderName + ' 的 API Key' : '请先选择提供者'"
                style="width: 400px"
                show-password
                :disabled="!selectedProvider"
              />
            </el-form-item>

            <el-form-item label="">
              <el-button type="primary" @click="saveApiKey" :loading="saving" :disabled="!selectedProvider || !apiKeyInput">
                <el-icon><Check /></el-icon> 保存到配置文件
              </el-button>
              <el-button @click="testApiKey" :disabled="!selectedProvider || !apiKeyInput">
                <el-icon><VideoPlay /></el-icon> 测试连接
              </el-button>
            </el-form-item>

            <el-form-item label="API Key状态">
              <el-space wrap>
                <el-tag
                  v-for="(status, name) in config.api_keys_status"
                  :key="name"
                  :type="status === 'configured' ? 'success' : 'warning'"
                >
                  {{ getProviderDisplayName(name) }}: {{ status === 'configured' ? '已配置' : '未配置' }}
                </el-tag>
              </el-space>
            </el-form-item>
          </el-form>
        </el-tab-pane>

        <el-tab-pane label="支持的模型" name="models">
          <el-table :data="allModels" border>
            <el-table-column prop="provider" label="提供者" width="120">
              <template #default="{ row }">
                <el-tag>{{ row.provider }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="models" label="支持的模型">
              <template #default="{ row }">
                <el-space wrap>
                  <el-tag
                    v-for="model in row.models"
                    :key="model"
                    size="small"
                  >
                    {{ model }}
                  </el-tag>
                </el-space>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="支持的方言" name="dialects">
          <el-table :data="dialects" border>
            <el-table-column prop="id" label="方言ID" width="120">
              <template #default="{ row }">
                <el-tag type="primary">{{ row.id }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="name" label="名称" width="150" />
            <el-table-column prop="description" label="说明" />
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="关于" name="about">
          <el-descriptions title="项目信息" :column="1" border>
            <el-descriptions-item label="项目名称">NL2SQL</el-descriptions-item>
            <el-descriptions-item label="版本">1.0.0</el-descriptions-item>
            <el-descriptions-item label="描述">
              自然语言转SQL工具，支持规则引擎和多种大模型
            </el-descriptions-item>
            <el-descriptions-item label="后端API">
              <el-link type="primary" href="/api" target="_blank">/api</el-link>
            </el-descriptions-item>
          </el-descriptions>

          <el-divider />

          <el-card shadow="never">
            <template #header>使用说明</template>
            <el-space direction="vertical" style="width: 100%">
              <div>
                <strong>1. SQL转换</strong>
                <p style="color: #909399; margin-top: 5px">
                  在转换页面输入自然语言查询，选择模式和方言，点击转换按钮生成SQL
                </p>
              </div>
              <div>
                <strong>2. 数据字典</strong>
                <p style="color: #909399; margin-top: 5px">
                  查看可用的数据表、字段和同义词映射
                </p>
              </div>
              <div>
                <strong>3. 运行模式</strong>
                <ul style="color: #909399; margin-top: 5px; padding-left: 20px">
                  <li><strong>混合模式</strong>：规则引擎优先，复杂场景自动走LLM</li>
                  <li><strong>规则引擎</strong>：纯规则，速度快但依赖预配置</li>
                  <li><strong>大模型</strong>：最灵活，但需要配置API Key</li>
                </ul>
              </div>
            </el-space>
          </el-card>
        </el-tab-pane>
      </el-tabs>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Check, VideoPlay } from '@element-plus/icons-vue'
import api from '@/api'

const activeTab = ref('llm')

const config = ref({
  default_provider: '',
  providers: [],
  api_keys_status: {},
})

const dialects = ref([])

const selectedProvider = ref('')
const apiKeyInput = ref('')
const saving = ref(false)

const availableProviders = ref([
  { id: 'deepseek', name: 'DeepSeek' },
  { id: 'dashscope', name: '通义千问' },
  { id: 'kimi', name: 'Kimi' },
  { id: 'minimax', name: 'MiniMax' },
  { id: 'openai', name: 'OpenAI' },
  { id: 'claude', name: 'Claude' },
])

const selectedProviderName = computed(() => {
  const p = availableProviders.value.find(p => p.id === selectedProvider.value)
  return p ? p.name : ''
})

const allModels = computed(() => {
  return config.value.providers.map(p => ({
    provider: p.display_name,
    models: p.models,
  }))
})

const getProviderDisplayName = (id) => {
  const p = availableProviders.value.find(p => p.id === id)
  return p ? p.name : id
}

const onProviderChange = () => {
  apiKeyInput.value = ''
}

const saveApiKey = async () => {
  if (!selectedProvider.value || !apiKeyInput.value) return

  saving.value = true
  try {
    await api.updateApiKey(selectedProvider.value, apiKeyInput.value)
    ElMessage.success('API Key 保存成功')
    const statusKey = selectedProvider.value
    config.value.api_keys_status[statusKey] = 'configured'
  } catch (error) {
    ElMessage.error(error.response?.data?.detail || '保存失败')
  } finally {
    saving.value = false
  }
}

const testApiKey = async () => {
  if (!selectedProvider.value || !apiKeyInput.value) {
    ElMessage.warning('请先选择提供者和输入 API Key')
    return
  }

  ElMessage.info('正在测试连接...')

  try {
    const testResult = await api.convert({
      text: 'test',
      mode: 'llm',
      provider: selectedProvider.value,
      model: undefined,
      dialect: 'hive',
      temperature: 0.1,
      use_schema: false,
      api_key: apiKeyInput.value,
    })

    if (testResult.data && testResult.data.sql) {
      ElMessage.success('连接成功！')
    } else {
      ElMessage.error('连接失败')
    }
  } catch (error) {
    ElMessage.error('连接失败')
  }
}

onMounted(async () => {
  try {
    const [configRes, dialectRes] = await Promise.all([
      api.getConfig(),
      api.getDialects(),
    ])
    config.value = configRes.data
    dialects.value = dialectRes.data.dialects
  } catch (error) {
    ElMessage.error('加载配置失败')
  }
})
</script>

<style scoped>
.config-page {
  height: 100%;
}

code {
  font-family: 'Consolas', 'Monaco', monospace;
  background-color: #f5f7fa;
  padding: 2px 6px;
  border-radius: 3px;
  font-size: 13px;
}
</style>