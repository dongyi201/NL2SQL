import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'

import App from './App.vue'
import ConvertPage from './pages/ConvertPage.vue'
import SchemaPage from './pages/SchemaPage.vue'
import ConfigPage from './pages/ConfigPage.vue'
import HistoryPage from './pages/HistoryPage.vue'

const routes = [
  { path: '/', redirect: '/convert' },
  { path: '/convert', name: 'convert', component: ConvertPage },
  { path: '/schema', name: 'schema', component: SchemaPage },
  { path: '/config', name: 'config', component: ConfigPage },
  { path: '/history', name: 'history', component: HistoryPage },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

const app = createApp(App)
app.use(router)
app.use(ElementPlus)

for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.mount('#app')