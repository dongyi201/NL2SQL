<template>
  <div class="app-container">
    <el-container>
      <el-aside width="200px">
        <div class="logo">
          <h2>NL2SQL</h2>
          <p>自然语言转SQL</p>
        </div>
        <el-menu
          :default-active="$route.path"
          router
          class="sidebar-menu"
        >
          <el-menu-item index="/convert">
            <el-icon><Edit /></el-icon>
            <span>SQL转换</span>
          </el-menu-item>
          <el-menu-item index="/schema">
            <el-icon><Document /></el-icon>
            <span>数据字典</span>
          </el-menu-item>
          <el-menu-item index="/history">
            <el-icon><Clock /></el-icon>
            <span>历史记录</span>
          </el-menu-item>
          <el-menu-item index="/config">
            <el-icon><Setting /></el-icon>
            <span>系统配置</span>
          </el-menu-item>
        </el-menu>
      </el-aside>

      <el-container>
        <el-header>
          <div class="header-content">
            <h1>{{ pageTitle }}</h1>
            <div class="header-info">
              <el-tag type="success">API运行中</el-tag>
            </div>
          </div>
        </el-header>

        <el-main>
          <router-view />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { Edit, Document, Clock, Setting } from '@element-plus/icons-vue'

const route = useRoute()

const pageTitle = computed(() => {
  const titles = {
    '/convert': 'SQL转换',
    '/schema': '数据字典',
    '/history': '历史记录',
    '/config': '系统配置',
  }
  return titles[route.path] || 'NL2SQL'
})
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Arial', 'Microsoft YaHei', sans-serif;
  background-color: #f5f7fa;
}

.app-container {
  height: 100vh;
}

.el-aside {
  background-color: #304156;
  color: #fff;
}

.logo {
  padding: 20px;
  text-align: center;
  border-bottom: 1px solid #3d4a5c;
}

.logo h2 {
  color: #409eff;
  margin-bottom: 5px;
}

.logo p {
  font-size: 12px;
  color: #909399;
}

.sidebar-menu {
  border-right: none;
  background-color: #304156;
}

.sidebar-menu .el-menu-item {
  color: #bfcbd9;
}

.sidebar-menu .el-menu-item:hover,
.sidebar-menu .el-menu-item.is-active {
  background-color: #263445;
  color: #409eff;
}

.el-header {
  background-color: #fff;
  border-bottom: 1px solid #e6e6e6;
  display: flex;
  align-items: center;
}

.header-content {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-content h1 {
  font-size: 18px;
  color: #303133;
}

.header-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.el-main {
  padding: 20px;
  overflow-y: auto;
}
</style>