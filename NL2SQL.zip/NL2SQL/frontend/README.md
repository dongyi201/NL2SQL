# NL2SQL Web 界面

基于 Vue 3 + FastAPI 的自然语言转 SQL 工具。

## 快速启动

### 方式一：一键启动（推荐）

```bash
python run_all.py
```

这将同时启动：
- 后端 API 服务: http://localhost:8000
- 前端界面: http://localhost:3000

### 方式二：分别启动

**1. 安装前端依赖**
```bash
cd frontend
npm install
```

**2. 启动后端**
```bash
python server.py
```

**3. 启动前端**
```bash
cd frontend
npm run dev
```

## 界面功能

### 1. SQL转换
- 输入自然语言查询
- 选择运行模式（混合/规则/LLM）
- 选择LLM提供者和模型
- 选择SQL方言
- 查看生成的SQL和置信度

### 2. 数据字典
- 浏览所有数据表
- 查看字段信息
- 搜索表名或字段
- 查看同义词映射
- 查看表关联关系

### 3. 历史记录
- 查看历史转换记录
- 恢复历史查询
- 删除记录

### 4. 系统配置
- 查看LLM配置状态
- 查看支持的模型列表
- 查看支持的方言

## API 接口

后端 API 访问地址: http://localhost:8000/api

| 接口 | 方法 | 说明 |
|------|------|------|
| `/api/convert` | POST | 自然语言转SQL |
| `/api/schemas` | GET | 获取数据字典 |
| `/api/dialects` | GET | 获取支持的方言 |
| `/api/providers` | GET | 获取LLM提供者 |
| `/api/config` | GET | 获取系统配置 |

## 配置 API Key

在 `config/llm_config.yaml` 文件中配置：

```yaml
llm:
  api_keys:
    deepseek: "your-api-key"
    dashscope: ""
    kimi: ""
    minimax: ""
    openai: ""
    claude: ""
```

## 技术栈

- **前端**: Vue 3 + Element Plus + Vite
- **后端**: FastAPI + Uvicorn
- **NL2SQL引擎**: 规则引擎 + LLM