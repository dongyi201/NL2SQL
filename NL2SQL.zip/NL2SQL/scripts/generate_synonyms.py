# -*- coding: utf-8 -*-
"""
根据 schema.yaml 中的元数据生成同义词映射
"""
import yaml
import re
from pathlib import Path


def generate_synonyms(schema):
    """生成同义词映射"""
    synonyms = {}

    for table in schema['tables']:
        table_name = table['name']
        table_chinese = table.get('chinese_name', '')
        
        # 表名相关同义词
        if table_chinese:
            # 中文名映射到表名
            for keyword in extract_keywords(table_chinese):
                if keyword not in synonyms:
                    synonyms[keyword] = f"table.{table_name}"
            
            # 表名的各种变体
            short_name = table_name.split('.')[-1]
            if short_name != table_name:
                synonyms[short_name] = f"table.{table_name}"

        # 字段相关同义词
        for col in table.get('columns', []):
            col_name = col['name']
            col_chinese = col.get('chinese_name', '')
            
            # 字段中文名
            if col_chinese:
                for keyword in extract_keywords(col_chinese):
                    if keyword not in synonyms:
                        synonyms[keyword] = f"column.{table_name}.{col_name}"
            
            # 字段别名
            for alias in col.get('aliases', []):
                if alias and alias not in synonyms:
                    synonyms[alias] = f"column.{table_name}.{col_name}"

            # 字段名变体（驼峰/下划线）
            if '_' in col_name:
                camel_case = re.sub(r'_([a-z])', lambda m: m.group(1).upper(), col_name)
                if camel_case != col_name and camel_case not in synonyms:
                    synonyms[camel_case] = f"column.{table_name}.{col_name}"

    return synonyms


def extract_keywords(text):
    """从文本中提取关键词"""
    import re
    
    keywords = []
    
    # 提取中文词
    chinese_words = re.findall(r'[\u4e00-\u9fa5]+', text)
    keywords.extend(chinese_words)
    
    # 提取英文单词
    english_words = re.findall(r'[a-zA-Z]+', text)
    keywords.extend([w.lower() for w in english_words])
    
    # 提取数字
    numbers = re.findall(r'\d+', text)
    keywords.extend(numbers)
    
    # 提取组合词中的部分
    parts = re.split(r'[,，、\s]+', text)
    for part in parts:
        part = part.strip()
        if len(part) >= 2:
            keywords.append(part)
    
    return list(set(keywords))


def main():
    schema_path = Path(__file__).parent.parent / 'config' / 'schema.yaml'
    
    with open(schema_path, 'r', encoding='utf-8') as f:
        schema = yaml.safe_load(f)
    
    print(f"正在从 {len(schema['tables'])} 张表生成同义词...")
    
    synonyms = generate_synonyms(schema)
    
    print(f"生成了 {len(synonyms)} 个同义词映射")
    
    # 更新 schema.yaml
    schema['synonym_map'] = synonyms
    
    with open(schema_path, 'w', encoding='utf-8') as f:
        yaml.dump(schema, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
    
    print("已更新 schema.yaml")


if __name__ == '__main__':
    main()
