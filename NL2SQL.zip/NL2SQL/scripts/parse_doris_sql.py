# -*- coding: utf-8 -*-
"""
Doris SQL 文件解析器 - 将建表语句转换为 schema.yaml 格式
"""
import os
import re
import yaml
from pathlib import Path


def parse_create_table(sql_dir):
    """解析 CREATE TABLE 语句"""
    tables = []

    # 列匹配模式：支持带反引号和不带反引号
    column_pattern = r'`?(\w+)`?\s+(VARCHAR\(\d+\)|STRING|DECIMAL\([^)]+\)|BIGINT|TINYINT|SMALLINT|INT|INTEGER|BOOLEAN|DATE|TIMESTAMP|DOUBLE|FLOAT|LARGEINT)\s*(?:COMMENT\s+\'([^\']+)\')?'

    for root, dirs, files in os.walk(sql_dir):
        for file in files:
            if not file.endswith('.sql'):
                continue

            file_path = os.path.join(root, file)
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 移除单行注释 (-- 开头)
            content = re.sub(r'--.*?$', '', content, flags=re.MULTILINE)
            # 移除块注释 (/* */)
            content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)

            # 提取表名
            table_match = re.search(r'CREATE\s+TABLE\s+([\w.]+)', content, re.IGNORECASE)
            if not table_match:
                continue

            table_name = table_match.group(1)

            # 提取表注释 (在 ) ENGINE ... DISTRIBUTED BY HASH 之后、PROPERTIES 之前的 COMMENT)
            table_comment = ''
            # 匹配 ) ENGINE=xxx KEY(...) COMMENT '表注释' DISTRIBUTED BY HASH 这种模式
            table_comment_match = re.search(
                r'\)\s*ENGINE\s*=\s*OLAP\s*(?:UNIQUE\s+KEY|DUPLICATE\s+KEY)\s*\([^)]+\)\s*COMMENT\s+\'([^\']+)\'',
                content,
                re.IGNORECASE
            )
            if table_comment_match:
                table_comment = table_comment_match.group(1).strip()
            else:
                # 备用方案：直接找 DISTRIBUTED BY HASH 之前的 COMMENT
                table_comment_match = re.search(
                    r'COMMENT\s+\'([^\']+)\'\s*\n\s*DISTRIBUTED\s+BY\s+HASH',
                    content,
                    re.IGNORECASE
                )
                if table_comment_match:
                    table_comment = table_comment_match.group(1).strip()

            # 根据表名生成中文名
            short_name = table_name.split('.')[-1]
            chinese_name = generate_chinese_name(short_name)

            # 提取列定义 (在 CREATE 和 ENGINE 之间的部分)
            columns_block_match = re.search(
                r'CREATE\s+TABLE\s+[\w.]+\s*\((.*?)\)\s*(?:ENGINE|$)',
                content,
                re.IGNORECASE | re.DOTALL
            )

            if not columns_block_match:
                continue

            columns_block = columns_block_match.group(1)

            # 提取每一列
            columns = []
            col_matches = re.findall(column_pattern, columns_block, re.IGNORECASE)

            for col_name, col_type, col_comment in col_matches:
                # 跳过分区字段
                if col_name.upper() in ('K1', 'K2', 'K3'):
                    continue

                col_info = {
                    'name': col_name,
                    'type': col_type.upper(),
                }

                # 添加中文名和别名
                if col_comment:
                    col_info['chinese_name'] = col_comment
                    # 生成别名
                    aliases = generate_aliases(col_name, col_comment)
                    if aliases:
                        col_info['aliases'] = aliases
                else:
                    # 根据列名自动生成中文名
                    col_info['chinese_name'] = generate_chinese_name(col_name)
                    col_info['aliases'] = generate_aliases_from_name(col_name)

                columns.append(col_info)

            if columns:
                table_info = {
                    'name': table_name,
                    'chinese_name': chinese_name,
                    'description': table_comment,
                    'columns': columns
                }
                tables.append(table_info)

    return tables


def generate_chinese_name(name):
    """根据名称生成中文名"""
    # 移除常见前缀和后缀
    name = name.lower()

    # 映射表
    mappings = {
        'id': 'ID',
        'order': '订单',
        'user': '用户',
        'sku': '商品',
        'province': '省份',
        'region': '区域',
        'city': '城市',
        'date': '日期',
        'time': '时间',
        'amount': '金额',
        'num': '数量',
        'status': '状态',
        'type': '类型',
        'name': '名称',
        'phone': '电话',
        'address': '地址',
        'price': '价格',
        'fee': '费用',
        'rate': '比率',
        'rate': '率',
        'total': '总计',
        'count': '计数',
        'sum': '求和',
        'avg': '平均',
        'max': '最大',
        'min': '最小',
        'payment': '支付',
        'refund': '退款',
        'coupon': '优惠券',
        'activity': '活动',
        'trade': '交易',
        'traffic': '流量',
        'source': '来源',
        'create': '创建',
        'update': '更新',
        'delete': '删除',
        'login': '登录',
        'register': '注册',
        'cart': '购物车',
        'inventory': '库存',
        'warehouse': '仓库',
        'product': '产品',
        'category': '分类',
        'attr': '属性',
        'value': '值',
        'image': '图片',
        'sale': '销售',
        'stock': '库存',
        'visitor': '访客',
        'page': '页面',
        'channel': '渠道',
        'conversion': '转化',
        'retention': '留存',
        'stats': '统计',
    }

    words = re.findall(r'[a-z]+', name)
    result = []
    for word in words:
        if word in mappings:
            result.append(mappings[word])
        else:
            result.append(word)

    return ''.join(result) if result else name


def generate_aliases(col_name, comment):
    """根据注释生成别名"""
    aliases = []

    if not comment:
        return None

    # 提取括号内的内容
    paren_match = re.search(r'([\u4e00-\u9fa5]+)\s*[\(（]([^)）]+)[\)）]', comment)
    if paren_match:
        aliases.append(paren_match.group(1))

    # 移除括号内容后提取剩余中文
    clean_comment = re.sub(r'[\(（][^)）]+[\)）]', '', comment)
    keywords = re.findall(r'[\u4e00-\u9fa5]+', clean_comment)
    for kw in keywords[:3]:
        if len(kw) >= 2 and kw not in aliases:
            aliases.append(kw)

    return aliases if aliases else None


def generate_aliases_from_name(col_name):
    """根据列名生成别名"""
    aliases = []
    name_lower = col_name.lower()

    # 驼峰转下划线
    if '_' not in col_name:
        camel = re.sub(r'([a-z])([A-Z])', lambda m: m.group(1) + '_' + m.group(2), col_name)
        aliases.append(camel.lower())

    # 下划线转驼峰
    if '_' in col_name:
        camel = re.sub(r'_([a-z])', lambda m: m.group(1).upper(), col_name)
        aliases.append(camel)

    # 移除常见后缀
    base_name = re.sub(r'_(id|no|num)$', '', name_lower, flags=re.IGNORECASE)
    if base_name != name_lower:
        aliases.append(base_name)

    return aliases if aliases else None


def convert_to_schema_yaml(tables, output_path):
    """将解析结果转换为 schema.yaml 格式"""
    schema = {
        'datasource': 'doris_warehouse',
        'tables': tables
    }

    with open(output_path, 'w', encoding='utf-8') as f:
        yaml.dump(schema, f, allow_unicode=True, default_flow_style=False, sort_keys=False)


def main():
    sql_dir = Path(__file__).parent.parent / 'dml'
    output_path = Path(__file__).parent.parent / 'config' / 'schema.yaml'

    print(f"解析目录: {sql_dir}")
    print(f"输出文件: {output_path}")

    tables = parse_create_table(str(sql_dir))
    print(f"解析到 {len(tables)} 个表")

    # 按表名排序
    tables.sort(key=lambda x: x['name'])

    convert_to_schema_yaml(tables, str(output_path))
    print("转换完成！")


if __name__ == '__main__':
    main()
