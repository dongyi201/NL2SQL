# -*- coding: utf-8 -*-
"""
解析 logical 文件夹中的 INSERT+SELECT 语句，提取表关联关系和元数据
"""
import os
import re
import yaml
from pathlib import Path


def parse_logical_file(file_path):
    """解析单个 logical SQL 文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 提取表名（从 INSERT INTO 语句）
    table_name = None
    insert_match = re.search(r'INSERT\s+INTO\s+([\w.]+)', content, re.IGNORECASE)
    if insert_match:
        table_name = insert_match.group(1).strip()

    # 从注释中提取元数据
    metadata = {
        'description': '',
        'data_sources': [],
        'calculation_granularity': '',
        'business_applications': [],
        'update_strategy': '',
        'field_descriptions': {},
        'scheduling_cycle': '',
        'scheduling_dependencies': [],
    }

    # 解析注释中的元数据
    lines = content.split('\n')
    in_field_descriptions = False

    for line in lines:
        # 移除注释符号
        line_clean = line.strip()
        
        # 检查字段说明部分
        if '字段说明:' in line_clean:
            in_field_descriptions = True
            continue
        if in_field_descriptions and line_clean.startswith('--'):
            # 解析字段说明: --   dt: 统计日期
            field_match = re.search(r'--\s*(\w+):\s*(.+)', line_clean)
            if field_match:
                metadata['field_descriptions'][field_match.group(1)] = field_match.group(2).strip()
            continue
        elif in_field_descriptions and not line_clean.startswith('--'):
            in_field_descriptions = False

        # 解析其他元数据
        if '-- 说明:' in line_clean or '功能描述:' in line_clean:
            match = re.search(r'(:|：)\s*(.+)', line_clean)
            if match:
                metadata['description'] = match.group(2).strip()
        elif '-- 数据来源:' in line_clean:
            # 支持多个数据来源，用逗号分隔
            match = re.search(r'(:|：)\s*(.+)', line_clean)
            if match:
                sources = match.group(2).strip()
                # 分割多个来源
                for source in re.split(r'[,，、]', sources):
                    source = source.strip()
                    if source and source not in metadata['data_sources']:
                        metadata['data_sources'].append(source)
        elif '-- 计算粒度:' in line_clean or '数据粒度:' in line_clean:
            match = re.search(r'(:|：)\s*(.+)', line_clean)
            if match:
                metadata['calculation_granularity'] = match.group(2).strip()
        elif '-- 业务应用:' in line_clean:
            match = re.search(r'(:|：)\s*(.+)', line_clean)
            if match:
                apps = match.group(2).strip()
                for app in re.split(r'[,，、]', apps):
                    app = app.strip()
                    if app and app not in metadata['business_applications']:
                        metadata['business_applications'].append(app)
        elif '-- 更新策略:' in line_clean:
            match = re.search(r'(:|：)\s*(.+)', line_clean)
            if match:
                metadata['update_strategy'] = match.group(2).strip()
        elif '调度周期:' in line_clean:
            match = re.search(r'(:|：)\s*(.+)', line_clean)
            if match:
                metadata['scheduling_cycle'] = match.group(2).strip()
        elif '调度依赖:' in line_clean:
            match = re.search(r'(:|：)\s*(.+)', line_clean)
            if match:
                metadata['scheduling_dependencies'].append(match.group(2).strip())

    # 从 SQL 语句中提取数据来源表（FROM/JOIN 子句）
    # 匹配 FROM table_name 或 JOIN table_name
    from_tables = re.findall(
        r'(?:FROM|JOIN|INNER\s+JOIN|LEFT\s+JOIN|RIGHT\s+JOIN|FULL\s+JOIN)\s+([\w.]+)',
        content,
        re.IGNORECASE
    )

    # 从 CTE 中提取表
    cte_tables = re.findall(
        r'FROM\s+([\w.]+)',
        content,
        re.IGNORECASE
    )

    # 合并所有来源表
    all_source_tables = []
    for table in from_tables + cte_tables:
        table = table.strip()
        # 排除 CTE 名称（通常不含点）
        if '.' in table and table != table_name:
            all_source_tables.append(table)

    # 去重
    all_source_tables = list(set(all_source_tables))
    
    # 添加到数据来源
    for table in all_source_tables:
        if table not in metadata['data_sources']:
            metadata['data_sources'].append(table)

    return {
        'table_name': table_name,
        **metadata
    }


def parse_all_logical_files(logical_dir):
    """解析所有 logical SQL 文件"""
    relations = []
    table_metadata = {}

    for root, dirs, files in os.walk(logical_dir):
        for file in files:
            if not file.endswith('.sql'):
                continue

            file_path = os.path.join(root, file)
            result = parse_logical_file(file_path)
            
            if result['table_name']:
                table_metadata[result['table_name']] = result
                
                # 创建表关联关系
                for source_table in result['data_sources']:
                    if source_table != result['table_name']:
                        relations.append({
                            'from_table': source_table,
                            'to_table': result['table_name'],
                            'relation_type': 'data_source'
                        })

    return {
        'relations': relations,
        'table_metadata': table_metadata
    }


def update_schema_yaml(schema_path, relations, table_metadata):
    """更新 schema.yaml 文件"""
    with open(schema_path, 'r', encoding='utf-8') as f:
        schema = yaml.safe_load(f)

    # 添加 relations
    schema['relations'] = relations

    # 更新表的元数据
    for table in schema['tables']:
        table_name = table['name']
        if table_name in table_metadata:
            meta = table_metadata[table_name]
            if meta['description'] and not table.get('description'):
                table['description'] = meta['description']
            if meta['calculation_granularity']:
                table['calculation_granularity'] = meta['calculation_granularity']
            if meta['business_applications']:
                table['business_applications'] = meta['business_applications']
            if meta['update_strategy']:
                table['update_strategy'] = meta['update_strategy']
            if meta['field_descriptions']:
                # 更新字段说明
                for col in table['columns']:
                    col_name = col['name']
                    if col_name in meta['field_descriptions']:
                        col['description'] = meta['field_descriptions'][col_name]

    with open(schema_path, 'w', encoding='utf-8') as f:
        yaml.dump(schema, f, allow_unicode=True, default_flow_style=False, sort_keys=False)


def main():
    logical_dir = Path(__file__).parent.parent / 'warehouse' / 'doris' / 'logical'
    schema_path = Path(__file__).parent.parent / 'config' / 'schema.yaml'

    print(f"解析目录: {logical_dir}")
    print(f"输出文件: {schema_path}")

    result = parse_all_logical_files(str(logical_dir))
    
    print(f"解析到 {len(result['table_metadata'])} 张表的元数据")
    print(f"解析到 {len(result['relations'])} 条表关联关系")

    update_schema_yaml(str(schema_path), result['relations'], result['table_metadata'])
    print("更新完成！")


if __name__ == '__main__':
    main()
