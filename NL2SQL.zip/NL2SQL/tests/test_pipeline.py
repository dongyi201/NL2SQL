# -*- coding: utf-8 -*-
"""单元测试 —— 验证各模块和整体流程。"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.schema.metadata import SchemaManager
from src.entity.extractor import EntityExtractor, extract_time, extract_compare
from src.pipeline import NL2SQLPipeline


def test_schema_loading():
    schema = SchemaManager()
    assert len(schema.tables) >= 3, "应至少有 3 张表"
    print("[OK] schema 加载成功")

    orders = schema.find_table("订单")
    assert orders is not None
    assert orders.name == "dw.dwd_order_info"
    print("[OK] 表名匹配成功")

    col = schema.find_column_globally("销售额")
    assert col is not None
    assert "order_amount" in col.name
    print("[OK] 字段同义词匹配成功")


def test_time_extraction():
    assert extract_time("最近7天") is not None
    assert extract_time("最近7天")["type"] == "LAST_N_DAYS"
    assert extract_time("昨天")["type"] == "YESTERDAY"
    assert extract_time("本月")["type"] == "THIS_MONTH"
    assert extract_time("没有时间关键词") is None
    print("[OK] 时间提取正常")


def test_compare_extraction():
    r = extract_compare("大于10000")
    assert r["op"] == ">"
    assert r["value"] == 10000.0

    r = extract_compare("低于500")
    assert r["op"] == "<"
    print("[OK] 比较条件提取正常")


def test_pipeline_basic():
    pipeline = NL2SQLPipeline()

    result = pipeline.convert("最近7天华北地区每天的销售额")

    assert result.confidence > 0.3
    assert "SELECT" in result.sql.upper()
    assert "order_amount" in result.sql.lower()
    assert "create_time" in result.sql.lower()
    print("[OK] 基础 Pipeline 正常")
    print(f"  SQL:\n{result.sql}")


def test_pipeline_multi_dialect():
    pipeline = NL2SQLPipeline()
    text = "最近7天华北地区每天的销售额"
    results = pipeline.convert_all_dialects(text)

    assert "hive" in results
    assert "doris" in results
    assert "starrocks" in results
    assert "flink" in results

    # 检查 Doris 方言转换了函数
    doris_sql = results["doris"].sql
    assert "INTERVAL" in doris_sql
    print("[OK] 多方言输出正常")

    for name, r in results.items():
        print(f"\n  [{name}] confidence={r.confidence:.0%}")
        print(f"  {r.sql[:120]}...")


def test_pipeline_no_results_hint():
    pipeline = NL2SQLPipeline()

    # 模糊输入，表没匹配到
    result = pipeline.convert("你好")
    assert result.sql.startswith("--"), "无表匹配应给出提示"
    print("[OK] 无匹配时兜底提示正常")


if __name__ == "__main__":
    test_schema_loading()
    test_time_extraction()
    test_compare_extraction()
    test_pipeline_basic()
    test_pipeline_multi_dialect()
    test_pipeline_no_results_hint()
    print("\n" + "=" * 50)
    print("  ALL TESTS PASSED!")
    print("=" * 50)
