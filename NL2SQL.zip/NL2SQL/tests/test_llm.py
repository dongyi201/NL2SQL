# -*- coding: utf-8 -*-
"""LLM 相关测试 —— 验证 LLM 提供者初始化和 LLM 生成流程。"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.llm.providers import get_provider
from src.llm.schema_formatter import SchemaFormatter
from src.llm.text_to_sql import LLMTextToSQL
from src.unified_pipeline import UnifiedPipeline


def test_provider_init():
    """测试各 LLM 提供者初始化"""
    providers = ["dashscope", "kimi", "openai", "claude", "minimax", "deepseek"]
    for p in providers:
        try:
            provider = get_provider(p)
            assert provider.name == p
            print(f"[OK] {p} provider initialized (api_key={'set' if provider.api_key else 'none'})")
        except Exception as e:
            print(f"[WARN] {p} provider init: {e}")


def test_schema_formatter():
    """测试数据字典格式化"""
    formatter = SchemaFormatter.__new__(SchemaFormatter)
    formatter.schema = None

    from src.schema.metadata import SchemaManager
    formatter.schema = SchemaManager()

    text = formatter.format_for_llm()
    assert "dw.dwd_order_info" in text
    assert "order_amount" in text
    print(f"[OK] Schema 格式化成功 ({len(text)} chars)")


def test_llm_text_to_sql_init():
    """测试 LLM TextToSQL 初始化（不调用 API）"""
    try:
        gen = LLMTextToSQL(
            provider="dashscope",
            model="qwen-turbo",
        )
        print(f"[OK] LLMTextToSQL initialized (provider={gen.provider_name}, model={gen.model})")
    except Exception as e:
        print(f"[WARN] LLMTextToSQL init: {e}")


def test_unified_pipeline_llm_mode():
    """测试 UnifiedPipeline 的 LLM 模式初始化"""
    try:
        pipeline = UnifiedPipeline(
            mode="llm",
            llm_provider="dashscope",
            llm_model="qwen-turbo",
        )
        print(f"[OK] UnifiedPipeline (llm mode) initialized")
    except Exception as e:
        print(f"[WARN] UnifiedPipeline init: {e}")


def test_hybrid_mode_with_rule():
    """测试混合模式（规则引擎兜底）"""
    pipeline = UnifiedPipeline(mode="hybrid")

    result = pipeline.convert("最近7天华北地区每天的销售额", dialect="hive")

    assert result.raw_text == "最近7天华北地区每天的销售额"
    assert result.source in ("rule", "llm")
    assert result.elapsed_ms >= 0

    print(f"[OK] Hybrid pipeline 正常 (mode={result.source}, confidence={result.confidence:.0%})")
    print(f"  SQL: {result.sql[:80]}...")


def test_llm_mode_no_api_key():
    """测试 LLM 模式（无 API Key 时优雅降级）"""
    pipeline = UnifiedPipeline(mode="llm", llm_provider="dashscope")

    result = pipeline.convert("张三最近7天的订单", dialect="hive")

    if result.error:
        print(f"[EXPECTED] LLM call failed without API key: {result.error[:60]}")
    else:
        print(f"[OK] LLM 生成成功 (mode={result.source})")
        print(f"  SQL: {result.sql[:100] if result.sql else 'empty'}...")


if __name__ == "__main__":
    print("\n=== LLM 模块测试 ===\n")

    test_provider_init()
    test_schema_formatter()
    test_llm_text_to_sql_init()
    test_unified_pipeline_llm_mode()
    test_hybrid_mode_with_rule()
    test_llm_mode_no_api_key()

    print("\n=== 测试完成 ===")