# -*- coding: utf-8 -*-
"""
实体抽取模块 —— 从自然语言中提取出 时间、比较条件、维度、指标、聚合方式 等结构化信息。
纯规则 + 正则实现，不依赖 LLM。
"""

import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional


@dataclass
class EntityResult:
    """实体抽取结果 —— 中间表示（IR）"""

    raw_text: str = ""
    intent: str = "SELECT"

    table: Optional[str] = None
    table_alias: Optional[str] = None

    metrics: list[dict] = field(default_factory=list)

    dimensions: list[str] = field(default_factory=list)

    filters: list[dict] = field(default_factory=list)

    order_by: list[dict] = field(default_factory=list)

    limit: Optional[int] = None

    confidence: float = 0.0


# ============================================================
#  时间表达式提取（正则）
# ============================================================

TIME_PATTERNS = [
    (re.compile(r"最近\s*(\d+)\s*天"), "LAST_N_DAYS"),
    (re.compile(r"最近\s*(\d+)\s*小时"), "LAST_N_HOURS"),
    (re.compile(r"最近\s*(\d+)\s*周"), "LAST_N_WEEKS"),
    (re.compile(r"最近\s*(\d+)\s*月"), "LAST_N_MONTHS"),
    (re.compile(r"昨天"), "YESTERDAY"),
    (re.compile(r"今天"), "TODAY"),
    (re.compile(r"本周"), "THIS_WEEK"),
    (re.compile(r"上周"), "LAST_WEEK"),
    (re.compile(r"本月"), "THIS_MONTH"),
    (re.compile(r"上月|上个月"), "LAST_MONTH"),
    (re.compile(r"本季度"), "THIS_QUARTER"),
]


def extract_time(text: str) -> Optional[dict]:
    """提取时间表达式。返回 None 表示没匹配到。"""
    for pattern, label in TIME_PATTERNS:
        m = pattern.search(text)
        if m:
            result = {"type": label, "raw": m.group(0)}
            if m.lastindex and m.lastindex >= 1:
                result["value"] = int(m.group(1))
            return result
    return None


# ============================================================
#  比较条件提取
# ============================================================

COMPARE_PATTERNS = [
    (re.compile(r"(大于|超过|高于|>)\s*(\d+(?:\.\d+)?)"), ">"),
    (re.compile(r"(大于等于|不小于|≥|>=)\s*(\d+(?:\.\d+)?)"), ">="),
    (re.compile(r"(小于|低于|<)\s*(\d+(?:\.\d+)?)"), "<"),
    (re.compile(r"(小于等于|不大于|≤|<=)\s*(\d+(?:\.\d+)?)"), "<="),
    (re.compile(r"(等于|=|是)\s*(\d+(?:\.\d+)?)\s*$"), "="),
]


def extract_compare(text: str) -> Optional[dict]:
    """提取比较条件  e.g. '大于10000' → {op: '>', value: 10000}"""
    for pattern, op in COMPARE_PATTERNS:
        m = pattern.search(text)
        if m:
            return {"op": op, "value": float(m.group(2)), "raw": m.group(0)}
    return None


# ============================================================
#  聚合 / 分组 关键词
# ============================================================

AGG_KEYWORDS = {
    "每天": "day",
    "每日": "day",
    "日": "day",
    "按天": "day",
    "每小时": "hour",
    "按月": "month",
    "每月": "month",
    "每周": "week",
    "按周": "week",
    "各": None,  # "各个地区" → 按地区分组
    "每个": None,
}

LIMIT_PATTERN = re.compile(r"(前|排名?前?|top)\s*(\d+)\s*(名|个|条|行)?")


def extract_agg_granularity(text: str) -> Optional[str]:
    """提取聚合粒度关键词"""
    for kw, gran in AGG_KEYWORDS.items():
        if kw in text:
            return gran
    return None


def extract_limit(text: str) -> Optional[int]:
    """提取 Top-N"""
    m = LIMIT_PATTERN.search(text)
    if m:
        return int(m.group(2))
    return None


# ============================================================
#  实体抽取主入口
# ============================================================

class EntityExtractor:
    def __init__(self, schema_manager):
        self.schema = schema_manager

    def extract(self, text: str) -> EntityResult:
        result = EntityResult(raw_text=text)

        result.intent = self._classify_intent(text)

        time_info = extract_time(text)
        compare_info = extract_compare(text)
        granularity = extract_agg_granularity(text)
        result.limit = extract_limit(text)

        # ---- 确定主表 ----
        result.table = self._find_table(text)

        # 去掉已知关键词，减轻干扰
        cleaned = text
        if time_info:
            cleaned = cleaned.replace(time_info["raw"], "")
        if compare_info:
            cleaned = cleaned.replace(compare_info["raw"], "")

        # ---- 提取维度 ----
        dims = self._extract_dimensions(cleaned)
        result.dimensions = dims

        # ---- 提取指标 ----
        metrics = self._extract_metrics(cleaned)
        result.metrics = metrics

        # ---- 构建过滤条件 ----
        filters = self._build_filters(
            result.table, text, time_info, compare_info
        )
        result.filters = filters

        # ---- 置信度估算 ----
        result.confidence = self._estimate_confidence(
            time_info, metrics, result.table
        )

        return result

    def _classify_intent(self, text: str) -> str:
        if any(w in text for w in ["插入", "新增", "添加"]):
            return "INSERT"
        if any(w in text for w in ["修改", "更新", "改成"]):
            return "UPDATE"
        if any(w in text for w in ["删除", "去掉", "清除"]):
            return "DELETE"
        return "SELECT"

    def _find_table(self, text: str) -> Optional[str]:
        candidates = []
        for table in self.schema.tables:
            for alias in table.aliases:
                if alias in text:
                    candidates.append((len(alias), table.name, alias))

        if candidates:
            candidates.sort(reverse=True)
            return candidates[0][1]

        for table in self.schema.tables:
            if table.match(text):
                return table.name

        for table in self.schema.tables:
            for col in table.columns:
                for alias in col.aliases:
                    if alias in text:
                        return table.name

        return None

    def _extract_dimensions(self, text: str) -> list[str]:
        """从文本中提取维度词 → 对应字段。"""
        dims = []
        for table in self.schema.tables:
            for col in table.columns:
                # 跳过数值型字段，它们大概率是指标
                if any(
                    t in col.type.upper()
                    for t in ("DECIMAL", "INT", "FLOAT", "DOUBLE")
                ):
                    continue
                for alias in col.aliases:
                    if alias in text:
                        dims.append(col.full_path)
                        break
        # 去重保序
        seen = set()
        unique = []
        for d in dims:
            if d not in seen:
                seen.add(d)
                unique.append(d)
        return unique

    def _extract_metrics(self, text: str) -> list[dict]:
        """从文本中提取指标词 → 指标表达式。"""
        metrics = []
        # 先查同义词映射
        for kw, expr in self.schema.synonym_map.items():
            if kw in text:
                metrics.append(
                    {"alias": kw, "expression": expr, "source": "synonym"}
                )
        return metrics

    def _build_filters(
        self,
        table_name: Optional[str],
        text: str,
        time_info: Optional[dict],
        compare_info: Optional[dict],
    ) -> list[dict]:
        """把时间和比较信息组装成过滤条件。"""
        filters = []

        # 时间过滤
        if time_info and table_name:
            time_col = self._find_time_column(table_name)
            if time_col:
                filters.append(
                    {
                        "field": time_col.full_path,
                        "op": ">=",
                        "value": self._time_to_expr(
                            time_info, time_col.full_path
                        ),
                        "raw_time": time_info,
                    }
                )

        # 比较过滤
        if compare_info:
            # 尝试匹配到一个数值字段
            metric_col = None
            for col in self.schema._all_columns:
                if any(
                    t in col.type.upper()
                    for t in ("DECIMAL", "INT", "FLOAT")
                ):
                    for alias in col.aliases:
                        if alias in text:
                            metric_col = col
                            break
            if metric_col:
                filters.append(
                    {
                        "field": metric_col.full_path,
                        "op": compare_info["op"],
                        "value": compare_info["value"],
                    }
                )

        return filters

    def _find_time_column(self, table_name: str) -> Optional:
        """在表中找到时间字段。"""
        for table in self.schema.tables:
            if table.name == table_name:
                for col in table.columns:
                    if col.is_time:
                        return col
        return None

    def _time_to_expr(self, time_info: dict, field_path: str) -> str:
        """把时间描述转成 SQL 表达式。"""
        t = time_info["type"]
        n = time_info.get("value", 1)

        if t == "LAST_N_DAYS":
            return f"DATE_SUB(CURRENT_DATE, {n})"
        elif t == "LAST_N_WEEKS":
            return f"DATE_SUB(CURRENT_DATE, {n * 7})"
        elif t == "LAST_N_MONTHS":
            return f"ADD_MONTHS(CURRENT_DATE, -{n})"
        elif t == "YESTERDAY":
            return "DATE_SUB(CURRENT_DATE, 1)"
        elif t == "TODAY":
            return "CURRENT_DATE"
        elif t == "LAST_WEEK":
            return "DATE_SUB(CURRENT_DATE, 7)"
        elif t == "THIS_WEEK":
            return "TRUNC(CURRENT_DATE, 'IW')"
        elif t == "THIS_MONTH":
            return "TRUNC(CURRENT_DATE, 'MM')"
        elif t == "LAST_MONTH":
            return "ADD_MONTHS(TRUNC(CURRENT_DATE, 'MM'), -1)"
        return "CURRENT_DATE"

    def _estimate_confidence(
        self, time_info, metrics, table
    ) -> float:
        """简单估算置信度 (0~1)。"""
        c = 0.0
        if table:
            c += 0.4
        if time_info:
            c += 0.2
        if metrics:
            c += 0.3
        return min(c, 1.0)
