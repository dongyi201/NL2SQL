# -*- coding: utf-8 -*-
"""
统一 Pipeline —— 整合规则引擎 + LLM，支持一键切换模式。
保留原有 rule-only 模式，同时支持 llm-only 和 hybrid 模式。
"""

import time
from dataclasses import dataclass, field
from typing import Optional

from src.schema.metadata import SchemaManager
from src.entity.extractor import EntityExtractor
from src.generator.sql_builder import SQLBuilder as RuleSQLBuilder
from src.llm.text_to_sql import LLMTextToSQL


@dataclass
class ConvertResult:
    raw_text: str
    sql: str
    dialect: str
    source: str
    confidence: float
    elapsed_ms: float
    ir: dict = field(default_factory=dict)
    error: Optional[str] = None


class UnifiedPipeline:
    """
    统一 NL2SQL Pipeline —— 支持三种运行模式：

    1. **rule** (规则引擎模式)
       - 纯规则引擎，速度快，零成本
       - 适合简单查询（已配置的表和字段）

    2. **llm** (大模型模式)
       - 调用 LLM API 生成 SQL
       - 支持任意表达，灵活通用

    3. **hybrid** (混合模式，默认)
       - 规则引擎优先，置信度不够时走 LLM
       - 兼顾速度与灵活性
    """

    def __init__(
        self,
        schema_config: str = None,
        mode: str = "hybrid",
        llm_provider: str = "dashscope",
        llm_model: str = "qwen-turbo",
        llm_api_key: str = None,
        rule_confidence_threshold: float = 0.7,
        **llm_kwargs,
    ):
        self.schema = SchemaManager(schema_config)
        self.mode = mode
        self.rule_threshold = rule_confidence_threshold

        # 规则引擎组件
        self.extractor = EntityExtractor(self.schema)
        self.rule_builder = RuleSQLBuilder(self.schema)

        # LLM 组件
        if mode in ("llm", "hybrid"):
            self.llm_generator = LLMTextToSQL(
                provider=llm_provider,
                model=llm_model,
                api_key=llm_api_key,
                schema_config=schema_config,
                use_rule_fallback=True,
                confidence_threshold=rule_confidence_threshold,
                **llm_kwargs,
            )
        else:
            self.llm_generator = None

    def convert(
        self,
        text: str,
        dialect: str = "hive",
        force_mode: str = None,
        temperature: float = 0.1,
        use_schema: bool = True,
    ) -> ConvertResult:
        """
        转换自然语言为 SQL。

        Args:
            text: 自然语言输入
            dialect: 目标方言 (hive / doris / starrocks / flink)
            force_mode: 强制使用某种模式 (rule / llm / hybrid)
            temperature: LLM 温度参数
            use_schema: 是否传入本地 schema 信息（True=参考模式，False=自由模式）

        Returns:
            ConvertResult 对象
        """
        start = time.perf_counter()
        mode = force_mode or self.mode

        if mode == "rule":
            return self._convert_by_rule(text, dialect)
        elif mode == "llm":
            return self._convert_by_llm(text, dialect, temperature, use_schema)
        else:  # hybrid
            return self._convert_hybrid(text, dialect, temperature, use_schema)

    def _convert_by_rule(self, text: str, dialect: str) -> ConvertResult:
        """纯规则引擎转换"""
        start = time.perf_counter()
        ir = self.extractor.extract(text)
        sql = self.rule_builder.build(ir)

        elapsed = (time.perf_counter() - start) * 1000

        return ConvertResult(
            raw_text=text,
            sql=sql if ir.table else f"-- 未识别到数据表，请明确要查询哪张表\n-- 原始输入: {text}",
            dialect=dialect,
            source="rule",
            confidence=ir.confidence,
            elapsed_ms=round(elapsed, 2),
            ir={
                "intent": ir.intent,
                "table": ir.table,
                "metrics": ir.metrics,
                "dimensions": ir.dimensions,
                "filters": ir.filters,
            },
        )

    def _convert_by_llm(
        self, text: str, dialect: str, temperature: float, use_schema: bool = True
    ) -> ConvertResult:
        """纯 LLM 转换"""
        start = time.perf_counter()
        result = self.llm_generator.convert(
            text, dialect, force_llm=True, temperature=temperature, use_schema=use_schema
        )

        elapsed = (time.perf_counter() - start) * 1000

        return ConvertResult(
            raw_text=text,
            sql=result["sql"],
            dialect=dialect,
            source=result["source"],
            confidence=result["confidence"],
            elapsed_ms=round(elapsed, 2),
            ir=result.get("ir", {}),
            error=result.get("error"),
        )

    def _convert_hybrid(
        self, text: str, dialect: str, temperature: float, use_schema: bool = True
    ) -> ConvertResult:
        """混合模式：规则优先，置信度不够时走 LLM"""
        # 如果不用 schema，规则引擎不应该执行，直接走 LLM
        if not use_schema:
            return self._convert_by_llm(text, dialect, temperature, use_schema)
        
        ir = self.extractor.extract(text)

        # 规则引擎置信度足够
        if ir.table and ir.confidence >= self.rule_threshold:
            return self._convert_by_rule(text, dialect)

        # 置信度不够，尝试 LLM
        if self.llm_generator:
            return self._convert_by_llm(text, dialect, temperature, use_schema)

        # LLM 未配置，返回规则结果（置信度可能较低）
        return self._convert_by_rule(text, dialect)

    def convert_all_dialects(self, text: str) -> dict[str, ConvertResult]:
        """将同一句话转换为所有方言"""
        results = {}
        for dialect in ["hive", "doris", "starrocks", "flink"]:
            results[dialect] = self.convert(text, dialect)
        return results