# -*- coding: utf-8 -*-
"""
Flink SQL 方言转换器。
Flink SQL 与 Hive / 标准 SQL 接近，使用 CURRENT_DATE，但有一些特有语法。
"""

from .base import BaseDialect


class FlinkDialect(BaseDialect):
    name = "flink"

    def convert(self, sql: str) -> str:
        sql = self._replace_current_timestamp(
            sql, "CURRENT_TIMESTAMP"
        )

        # Flink SQL 兼容 Hive 风格函数，不需要大改动
        return f"-- Flink SQL\n{sql}"
