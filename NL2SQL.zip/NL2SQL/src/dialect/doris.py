# -*- coding: utf-8 -*-
"""
Doris 方言转换器。
Doris / StarRocks 函数接近 MySQL 风格，时间函数差异较大。
"""

from .base import BaseDialect
import re


class DorisDialect(BaseDialect):
    name = "doris"

    def convert(self, sql: str) -> str:
        sql = self._replace_date_sub_with_interval(sql)

        sql = self._replace_current_timestamp(
            sql, "CURRENT_TIMESTAMP()"
        )

        sql = self._replace_current_date(sql, "CURDATE()")

        sql = self._replace(
            sql,
            r"DATE_ADD\s*\(\s*(\w+)\s*,\s*(\d+)\s*\)",
            r"DATE_ADD(\1, INTERVAL \2 DAY)",
        )

        sql = self._replace(
            sql,
            r"ADD_MONTHS\s*\(\s*(\w+)\s*,\s*(-?\d+)\s*\)",
            r"DATE_ADD(\1, INTERVAL \2 MONTH)",
        )

        return f"-- Doris SQL\n{sql}"

    def _replace_date_sub_with_interval(self, sql: str) -> str:
        pattern = re.compile(
            r"DATE_SUB\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(\d+)\s*\)",
            re.IGNORECASE,
        )
        return pattern.sub(r"DATE_SUB(\1, INTERVAL \2 DAY)", sql)
