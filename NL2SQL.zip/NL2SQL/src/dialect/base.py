# -*- coding: utf-8 -*-
"""
方言转换基类 —— 定义统一接口。
"""

import re
from abc import ABC, abstractmethod


class BaseDialect(ABC):
    """所有 SQL 方言的基类"""

    name: str = "standard"

    @abstractmethod
    def convert(self, standard_sql: str) -> str:
        ...

    def _replace(self, sql, pattern, replacement):
        return re.sub(pattern, replacement, sql, flags=re.IGNORECASE)

    def _replace_date_sub(self, sql, new_func):
        return self._replace(
            sql, r"DATE_SUB\s*\(\s*(\w+)\s*,\s*(\d+)\s*\)", new_func
        )

    def _replace_current_date(self, sql, new_val):
        return self._replace(sql, r"CURRENT_DATE", new_val)

    def _replace_current_timestamp(self, sql, new_val):
        return self._replace(sql, r"CURRENT_TIMESTAMP", new_val)

    def _replace_add_months(self, sql, new_func):
        return self._replace(
            sql, r"ADD_MONTHS\s*\(\s*(\w+)\s*,\s*(-?\d+)\s*\)", new_func
        )

    def _replace_trunc(self, sql, new_func):
        return self._replace(
            sql,
            r"TRUNC\s*\(\s*([^,]+?)\s*,\s*'(\w+)'\s*\)",
            new_func,
        )

    def _replace_limit(self, sql, new_template):
        return self._replace(
            sql,
            r"LIMIT\s+(\d+)",
            lambda m: new_template.format(limit=m.group(1)),
        )

    def _replace_format_datetime(self, sql, new_func):
        return self._replace(
            sql,
            r"DATE_FORMAT\s*\(\s*(.+?)\s*,\s*'([^']+)'\s*\)",
            new_func,
        )
