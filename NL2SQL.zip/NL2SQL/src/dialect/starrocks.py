# -*- coding: utf-8 -*-
"""
StarRocks 方言转换器。
与 Doris 高度相似（同源），时间函数差异小。
"""

from .base import BaseDialect
import re


class StarRocksDialect(BaseDialect):
    name = "starrocks"

    def convert(self, sql: str) -> str:
        sql = self._replace_date_sub_with_interval(sql)

        sql = self._replace_current_timestamp(
            sql, "CURRENT_TIMESTAMP()"
        )

        sql = self._replace_current_date(sql, "CURDATE()")

        sql = self._replace(
            sql,
            r"DATE_ADD\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(\d+)\s*\)",
            r"DATE_ADD(\1, \2)",
        )

        sql = self._replace(
            sql,
            r"ADD_MONTHS\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(-?\d+)\s*\)",
            r"DATE_ADD(\1, \2)",
        )

        return f"-- StarRocks SQL\n{sql}"

    def _replace_date_sub_with_interval(self, sql: str) -> str:
        pattern = re.compile(
            r"DATE_SUB\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(\d+)\s*\)",
            re.IGNORECASE,
        )
        return pattern.sub(r"DATE_SUB(\1, \2)", sql)
