# -*- coding: utf-8 -*-
"""
基于 sqlglot 的 SQL 方言验证和转换器。
使用 sqlglot 库确保 SQL 语法正确性，并进行方言间转换。
"""

import sqlglot
from typing import Optional, Tuple


class SQLGlotDialectConverter:
    """
    使用 sqlglot 进行 SQL 方言验证和转换。

    支持的方言: hive, doris, starrocks, flink
    """

    SUPPORTED_DIALECTS = ["hive", "doris", "starrocks", "flink"]

    DIALECT_MAP = {
        "hive": "hive",
        "doris": "doris",
        "starrocks": "starrocks",
        "flink": "spark",  # Flink SQL 与 Spark 语法最接近
    }

    def __init__(self):
        pass

    def validate(self, sql: str, dialect: str = "hive") -> Tuple[bool, Optional[str], Optional[str]]:
        """
        验证 SQL 语法是否正确。

        Args:
            sql: SQL 语句
            dialect: 目标方言

        Returns:
            (是否有效, 错误信息, 规范化后的 SQL)
        """
        sqlglot_dialect = self.DIALECT_MAP.get(dialect, dialect)

        try:
            parsed = sqlglot.parse_one(sql, dialect=sqlglot_dialect)
            normalized = parsed.sql(dialect=sqlglot_dialect)
            return True, None, normalized
        except sqlglot.errors.ParseError as e:
            return False, f"语法错误: {str(e)}", None
        except Exception as e:
            return False, f"解析失败: {str(e)}", None

    def transpile(self, sql: str, from_dialect: str, to_dialect: str) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        将 SQL 从一种方言转换为另一种方言。

        Args:
            sql: 原始 SQL
            from_dialect: 源方言
            to_dialect: 目标方言

        Returns:
            (是否成功, 错误信息, 转换后的 SQL)
        """
        sqlglot_from = self.DIALECT_MAP.get(from_dialect, from_dialect)
        sqlglot_to = self.DIALECT_MAP.get(to_dialect, to_dialect)

        try:
            result = sqlglot.transpile(sql, read=sqlglot_from, write=sqlglot_to, pretty=False)
            if result:
                return True, None, result[0]
            return False, "转换结果为空", None
        except sqlglot.errors.ParseError as e:
            return False, f"源 SQL 语法错误: {str(e)}", None
        except Exception as e:
            return False, f"转换失败: {str(e)}", None

    def normalize(self, sql: str, dialect: str) -> str:
        """
        规范化 SQL，使用指定方言的语法规则。

        Args:
            sql: SQL 语句
            dialect: 方言

        Returns:
            规范化后的 SQL
        """
        sqlglot_dialect = self.DIALECT_MAP.get(dialect, dialect)

        try:
            parsed = sqlglot.parse_one(sql, dialect=sqlglot_dialect)
            return parsed.sql(dialect=sqlglot_dialect)
        except Exception:
            return sql

    def convert_dialect(self, sql: str, target_dialect: str) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        将 SQL 转换为目标方言，同时验证语法正确性。

        这是主要入口方法，会先解析再生成目标方言的 SQL。

        Args:
            sql: 原始 SQL
            target_dialect: 目标方言 (hive/doris/starrocks/flink)

        Returns:
            (是否成功, 错误信息, 转换后的 SQL)
        """
        sqlglot_dialect = self.DIALECT_MAP.get(target_dialect, target_dialect)

        try:
            parsed = sqlglot.parse_one(sql, dialect=sqlglot_dialect)
            result = parsed.sql(dialect=sqlglot_dialect)
            return True, None, result
        except sqlglot.errors.ParseError as e:
            return False, f"SQL 语法错误: {str(e)}", None
        except Exception as e:
            return False, f"转换失败: {str(e)}", None

    def is_supported(self, dialect: str) -> bool:
        """检查方言是否支持"""
        return dialect.lower() in self.SUPPORTED_DIALECTS


def validate_sql(sql: str, dialect: str = "hive") -> Tuple[bool, Optional[str]]:
    """
    验证 SQL 语法是否正确（快捷函数）。

    Args:
        sql: SQL 语句
        dialect: 方言

    Returns:
        (是否有效, 错误信息或 None)
    """
    converter = SQLGlotDialectConverter()
    valid, error, _ = converter.validate(sql, dialect)
    if valid:
        return True, None
    return False, error


def convert_sql(sql: str, from_dialect: str, to_dialect: str) -> Tuple[bool, Optional[str]]:
    """
    转换 SQL 方言（快捷函数）。

    Args:
        sql: 原始 SQL
        from_dialect: 源方言
        to_dialect: 目标方言

    Returns:
        (是否成功, 转换后的 SQL 或错误信息)
    """
    converter = SQLGlotDialectConverter()
    valid, error, result = converter.transpile(sql, from_dialect, to_dialect)
    if valid:
        return True, result
    return False, error


if __name__ == "__main__":
    converter = SQLGlotDialectConverter()

    test_sqls = [
        "SELECT id, name, SUM(amount) AS total FROM orders WHERE dt = '2024-01-01' GROUP BY id, name",
        "SELECT a.id, b.name FROM table1 a LEFT JOIN table2 b ON a.id = b.id",
        "SELECT * FROM users WHERE created_at >= DATE_SUB(CURRENT_DATE, 7)",
    ]

    print("=" * 60)
    print("SQL 语法验证测试")
    print("=" * 60)

    for sql in test_sqls:
        print(f"\n原始 SQL: {sql[:50]}...")
        for dialect in ["hive", "doris", "starrocks", "flink"]:
            valid, error, normalized = converter.validate(sql, dialect)
            status = "[OK]" if valid else "[X]"
            if valid:
                print(f"  {status} {dialect}: {normalized[:60]}...")
            else:
                print(f"  {status} {dialect}: {error}")

    print("\n" + "=" * 60)
    print("方言转换测试 (Hive -> 其他)")
    print("=" * 60)

    hive_sql = "SELECT id, SUM(amount) FROM orders WHERE dt = CURRENT_DATE GROUP BY id"
    print(f"\n源 SQL (Hive): {hive_sql}")

    for target in ["doris", "starrocks", "flink"]:
        valid, error, result = converter.transpile(hive_sql, "hive", target)
        if valid:
            print(f"  -> {target}: {result}")
        else:
            print(f"  -> {target}: 错误 - {error}")