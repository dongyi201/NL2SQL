# -*- coding: utf-8 -*-
"""
Hive 方言转换器。
Hive 的函数特点：CURRENT_DATE 用 CURRENT_DATE，
DATE_SUB / ADD_MONTHS 原生支持。
"""

from .base import BaseDialect


class HiveDialect(BaseDialect):
    name = "hive"

    def convert(self, sql: str) -> str:
        """Hive 与标准 SQL 基本一致，不需要大幅转换。"""
        # Hive 基本兼容标准 SQL，无需转换
        return f"-- Hive SQL\n{sql}"
