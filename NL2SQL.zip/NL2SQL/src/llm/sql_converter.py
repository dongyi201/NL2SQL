# -*- coding: utf-8 -*-
"""
LLM 输出的 SQL 方言转换器。
由于 LLM 生成 SQL 时会根据 prompt 中的 dialect_hint 生成对应方言，
但仍可能存在不准确的情况，这里提供一个后处理转换器来修正常见差异。
"""

import re
from typing import Optional


class LLMSQLConverter:
    """
    对 LLM 生成的 SQL 进行方言转换和修正。
    主要处理 LLM 容易出错的时间函数差异。
    """

    HIVE_TO_DORIS_REPLACEMENTS = [
        (r"CURRENT_DATE(?!\()", "CURDATE()"),
        (r"DATE_SUB\s*\(\s*CURRENT_DATE\s*,\s*(\d+)\s*\)", r"DATE_SUB(CURDATE(), INTERVAL \1 DAY)"),
        (r"DATE_ADD\s*\(\s*CURRENT_DATE\s*,\s*(\d+)\s*\)", r"DATE_ADD(CURDATE(), INTERVAL \1 DAY)"),
        (r"ADD_MONTHS\s*\(\s*CURRENT_DATE\s*,\s*(-?\d+)\s*\)", r"DATE_SUB(CURDATE(), INTERVAL \1 MONTH)"),
        (r"CURRENT_TIMESTAMP(?!\()", "CURRENT_TIMESTAMP()"),
    ]

    HIVE_TO_STARROCKS_REPLACEMENTS = [
        (r"CURRENT_DATE(?!\()", "CURDATE()"),
        (r"DATE_SUB\s*\(\s*CURRENT_DATE\s*,\s*(\d+)\s*\)", r"DATE_SUB(CURDATE(), \1)"),
        (r"ADD_MONTHS\s*\(\s*CURRENT_DATE\s*,\s*(-?\d+)\s*\)", r"DATE_ADD(CURDATE(), \1)"),
        (r"TRUNC\s*\(\s*CURRENT_DATE\s*,\s*'([^']+)'\s*\)", r"DATE_TRUNC(CURDATE(), '\1')"),
        (r"CURRENT_TIMESTAMP(?!\()", "CURRENT_TIMESTAMP()"),
    ]

    HIVE_TO_FLINK_REPLACEMENTS = [
        (r"TRUNC\s*\(\s*CURRENT_DATE\s*,\s*'([^']+)'\s*\)", r"DATE_TRUNC(CURRENT_DATE, '\1')"),
    ]

    HIVE_TO_HIVE_REPLACEMENTS = [
        # Hive 自身不需要大改，但可以统一风格
    ]

    CONVERTER_MAP = {
        ("hive", "hive"): HIVE_TO_HIVE_REPLACEMENTS,
        ("hive", "doris"): HIVE_TO_DORIS_REPLACEMENTS,
        ("hive", "starrocks"): HIVE_TO_STARROCKS_REPLACEMENTS,
        ("hive", "flink"): HIVE_TO_FLINK_REPLACEMENTS,
        ("doris", "doris"): [],
        ("doris", "hive"): [],  # Doris 生成 Hive 需要手动处理
        ("doris", "starrocks"): [],
        ("doris", "flink"): [],
        ("starrocks", "starrocks"): [],
        ("starrocks", "doris"): [],
        ("starrocks", "hive"): [],
        ("starrocks", "flink"): [],
        ("flink", "flink"): [],
        ("flink", "hive"): [],
        ("flink", "doris"): [],
        ("flink", "starrocks"): [],
    }

    def convert(self, sql: str, from_dialect: str, to_dialect: str) -> str:
        """
        将 SQL 从一种方言转换到另一种。

        Args:
            sql: 原始 SQL
            from_dialect: 源方言
            to_dialect: 目标方言

        Returns:
            转换后的 SQL
        """
        if from_dialect == to_dialect:
            return sql

        replacements = self.CONVERTER_MAP.get((from_dialect, to_dialect), [])

        result = sql
        for pattern, replacement in replacements:
            result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)

        return result

    def convert_to_dialect(self, sql: str, dialect: str) -> str:
        """将 SQL 转换为指定方言（自动推断源方言）"""
        return self.convert(sql, "hive", dialect)