# -*- coding: utf-8 -*-
"""
OpenAI GPT 系列 (GPT-4 / GPT-4o / GPT-3.5) 提供者。
需要安装: pip install openai
"""

import os
from .base import LLMProvider


class OpenAIProvider(LLMProvider):
    name = "openai"

    def __init__(
        self,
        api_key: str = None,
        model: str = "gpt-4o-mini",
        base_url: str = None,
        **kwargs,
    ):
        super().__init__(api_key, model, **kwargs)
        self.base_url = base_url
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from openai import OpenAI

                self._client = OpenAI(
                    api_key=self.api_key or os.getenv("OPENAI_API_KEY"),
                    base_url=self.base_url,
                )
            except ImportError:
                raise RuntimeError(
                    "请安装 openai 库: pip install openai"
                )
        return self._client

    def chat(self, messages: list[dict], **kwargs) -> str:
        client = self._get_client()

        params = {
            "model": self.model,
            "messages": messages,
            "temperature": kwargs.get("temperature", 0.1),
            "max_tokens": kwargs.get("max_tokens", 1024),
        }

        # OpenAI 兼容接口（如 Azure OpenAI、LocalAI 等）
        if self.base_url:
            params["model"] = kwargs.get("model", self.model)

        response = client.chat.completions.create(**params)
        return response.choices[0].message.content