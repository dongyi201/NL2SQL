# -*- coding: utf-8 -*-
"""
Anthropic Claude 系列 (Claude 3.5 / Claude 3) 提供者。
需要安装: pip install anthropic
"""

import os
from .base import LLMProvider


class ClaudeProvider(LLMProvider):
    name = "claude"

    def __init__(
        self,
        api_key: str = None,
        model: str = "claude-3-5-sonnet-20241022",
        **kwargs,
    ):
        super().__init__(api_key, model, **kwargs)
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from anthropic import Anthropic

                self._client = Anthropic(
                    api_key=self.api_key or os.getenv("ANTHROPIC_API_KEY")
                )
            except ImportError:
                raise RuntimeError(
                    "请安装 anthropic 库: pip install anthropic"
                )
        return self._client

    def chat(self, messages: list[dict], **kwargs) -> str:
        client = self._get_client()

        # 把 messages 转为 Claude 格式
        system_msg = ""
        claude_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                claude_messages.append(
                    {"role": msg["role"], "content": msg["content"]}
                )

        response = client.messages.create(
            model=self.model,
            system=system_msg or None,
            messages=claude_messages,
            temperature=kwargs.get("temperature", 0.1),
            max_tokens=kwargs.get("max_tokens", 1024),
        )

        return response.content[0].text