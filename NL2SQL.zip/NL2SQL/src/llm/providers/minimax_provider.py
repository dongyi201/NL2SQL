# -*- coding: utf-8 -*-
"""
MiniMax 提供者 —— 兼容 OpenAI 接口格式。
需要安装: pip install openai
"""

import os
from .base import LLMProvider


class MiniMaxProvider(LLMProvider):
    name = "minimax"

    def __init__(
        self,
        api_key: str = None,
        model: str = "abab6.5s-chat",
        group_id: str = None,
        **kwargs,
    ):
        super().__init__(api_key, model, **kwargs)
        self.group_id = group_id or os.getenv("MINIMAX_GROUP_ID")
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from openai import OpenAI

                self._client = OpenAI(
                    api_key=self.api_key or os.getenv("MINIMAX_API_KEY"),
                    base_url="https://api.minimax.chat/v1",
                )
            except ImportError:
                raise RuntimeError(
                    "请安装 openai 库: pip install openai"
                )
        return self._client

    def chat(self, messages: list[dict], **kwargs) -> str:
        client = self._get_client()

        # MiniMax 需要 group_id 参数，通过 extra_headers 传入
        extra_headers = {}
        if self.group_id:
            extra_headers["MM-Group-Id"] = self.group_id

        response = client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=kwargs.get("temperature", 0.1),
            max_tokens=kwargs.get("max_tokens", 1024),
            extra_headers=extra_headers if extra_headers else None,
        )

        return response.choices[0].message.content