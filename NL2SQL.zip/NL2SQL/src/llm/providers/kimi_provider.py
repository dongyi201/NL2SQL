# -*- coding: utf-8 -*-
"""
月之暗面 Kimi (Moonshot AI) 提供者 —— 兼容 OpenAI 接口格式。
需要安装: pip install openai
"""

import os
from .base import LLMProvider


class KimiProvider(LLMProvider):
    name = "kimi"

    def __init__(
        self,
        api_key: str = None,
        model: str = "moonshot-v1-8k",
        **kwargs,
    ):
        super().__init__(api_key, model, **kwargs)
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from openai import OpenAI

                self._client = OpenAI(
                    api_key=self.api_key or os.getenv("MOONSHOT_API_KEY"),
                    base_url="https://api.moonshot.cn/v1",
                )
            except ImportError:
                raise RuntimeError(
                    "请安装 openai 库: pip install openai"
                )
        return self._client

    def chat(self, messages: list[dict], **kwargs) -> str:
        client = self._get_client()

        response = client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=kwargs.get("temperature", 0.1),
            max_tokens=kwargs.get("max_tokens", 1024),
        )

        return response.choices[0].message.content