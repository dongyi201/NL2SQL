# -*- coding: utf-8 -*-
"""
阿里云通义千问 (DashScope) 提供者。
需要安装: pip install openai
或: pip install dashscope
"""

import os
from .base import LLMProvider


class DashScopeProvider(LLMProvider):
    name = "dashscope"

    def __init__(
        self,
        api_key: str = None,
        model: str = "qwen-turbo",
        **kwargs,
    ):
        super().__init__(api_key, model, **kwargs)
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                from openai import OpenAI

                self._client = OpenAI(
                    api_key=self.api_key or os.getenv("DASHSCOPE_API_KEY"),
                    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
                )
            except ImportError:
                raise RuntimeError(
                    "请安装 openai 库: pip install openai"
                )
        return self._client

    def chat(self, messages: list[dict], **kwargs) -> str:
        client = self._get_client()

        response = client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=kwargs.get("temperature", 0.1),
            max_tokens=kwargs.get("max_tokens", 1024),
        )

        return response.choices[0].message.content