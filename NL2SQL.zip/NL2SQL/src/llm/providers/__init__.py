# -*- coding: utf-8 -*-
"""
LLM 提供商配置 —— 支持多种大模型 API。

支持的提供者:
  - openai     : OpenAI GPT 系列
  - claude     : Anthropic Claude 系列
  - kimi       : 月之暗面 Kimi
  - dashscope  : 阿里云通义千问
  - minimax    : MiniMax 海螺AI
  - deepseek   : DeepSeek 深度求索

使用方式：
  1. 设置环境变量（推荐）
  2. 命令行参数传入
"""

from .openai_provider import OpenAIProvider
from .claude_provider import ClaudeProvider
from .kimi_provider import KimiProvider
from .dashscope_provider import DashScopeProvider
from .minimax_provider import MiniMaxProvider
from .deepseek_provider import DeepSeekProvider

_PROVIDERS = {
    "openai": OpenAIProvider,
    "claude": ClaudeProvider,
    "kimi": KimiProvider,
    "dashscope": DashScopeProvider,
    "minimax": MiniMaxProvider,
    "deepseek": DeepSeekProvider,
}


def get_provider(provider_name: str, api_key: str = None, **kwargs):
    """
    获取 LLM 提供者实例。

    Args:
        provider_name: 提供者名称 (openai / claude / kimi / dashscope / minimax / deepseek)
        api_key: API Key（可从环境变量读取）
        **kwargs: 其他配置参数

    Returns:
        LLMProvider 实例
    """
    cls = _PROVIDERS.get(provider_name.lower())
    if cls is None:
        raise ValueError(
            f"Unknown provider: {provider_name}. "
            f"Available: {list(_PROVIDERS.keys())}"
        )
    return cls(api_key=api_key, **kwargs)