# -*- coding: utf-8 -*-
"""LLM Provider 基类 —— 定义统一接口。"""

from abc import ABC, abstractmethod


class LLMProvider(ABC):
    """所有 LLM 提供者的基类"""

    def __init__(self, api_key: str = None, model: str = None, **kwargs):
        self.api_key = api_key
        self.model = model
        self.extra_config = kwargs

    @abstractmethod
    def chat(self, messages: list[dict], **kwargs) -> str:
        """
        调用 LLM 生成文本。

        Args:
            messages: [{role: str, content: str}, ...]
            **kwargs: provider 特有参数

        Returns:
            LLM 回复的文本内容
        """
        ...

    def system_message(self, content: str) -> dict:
        return {"role": "system", "content": content}

    def user_message(self, content: str) -> dict:
        return {"role": "user", "content": content}

    def assistant_message(self, content: str) -> dict:
        return {"role": "assistant", "content": content}