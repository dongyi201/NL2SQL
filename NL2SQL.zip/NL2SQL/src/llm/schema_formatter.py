# -*- coding: utf-8 -*-
"""
数据字典格式化工具 —— 将 schema.yaml 转为 LLM 可理解的文本描述。
"""

from src.schema.metadata import SchemaManager


class SchemaFormatter:
    """将数据字典格式化为 LLM Prompt 可用的文本"""

    def __init__(self, schema: SchemaManager):
        self.schema = schema

    def format_for_llm(self) -> str:
        """生成完整的 schema 描述文本"""
        lines = []
        lines.append("# 可用数据表和字段\n")

        for table in self.schema.tables:
            lines.append(f"## {table.name}")
            if table.chinese_name:
                lines.append(f"**{table.chinese_name}**")
            if table.description:
                lines.append(f"说明: {table.description}")

            lines.append("字段:")
            for col in table.columns:
                type_info = col.type or "STRING"
                col_desc = f"  - {col.name} ({type_info}): {col.chinese_name}"
                if col.aliases:
                    col_desc += f" | 别名: {', '.join(col.aliases)}"
                if col.enum_values:
                    if isinstance(col.enum_values, list):
                        col_desc += f" | 可选值: {', '.join(str(v) for v in col.enum_values)}"
                    else:
                        col_desc += f" | 枚举映射: {col.enum_values}"
                lines.append(col_desc)
            lines.append("")

        if self.schema.relations:
            lines.append("# 表关联关系")
            for rel in self.schema.relations:
                lines.append(
                    f"- {rel['left_table']} 与 {rel['right_table']} "
                    f"可通过 {rel['join_condition']} 关联 (JOIN: {rel['join_type']})"
                )
            lines.append("")

        return "\n".join(lines)

    def format_for_llm_minimal(self) -> str:
        """简化版：只包含表名和字段"""
        lines = []
        for table in self.schema.tables:
            col_names = [c.name for c in table.columns]
            lines.append(f"{table.name}: {', '.join(col_names)}")
        return "\n".join(lines)

    def format_table_column_list(self) -> str:
        """仅列出每个表的字段名（不包含类型和描述）"""
        parts = []
        for table in self.schema.tables:
            cols = [c.name for c in table.columns]
            parts.append(f"{table.name}({', '.join(cols)})")
        return "; ".join(parts)