# -*- coding: utf-8 -*-
"""
LLM 配置文件加载器 —— 从 llm_config.yaml 读取 API Key 和配置。
"""

import os
import yaml
from typing import Optional


class LLMConfig:
    """
    LLM 配置管理器。

    支持从配置文件读取 API Key，优先级：
    1. 环境变量（最高）
    2. 配置文件（llm_config.yaml）
    """

    _instance = None
    _config = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load_config()
        return cls._instance

    def _load_config(self):
        """加载配置文件"""
        # 使用项目根目录作为基准
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        config_path = os.path.join(project_root, "config", "llm_config.yaml")
        config_path = os.path.abspath(config_path)

        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                self._config = yaml.safe_load(f)
        else:
            self._config = {}

    def reload(self):
        """重新加载配置文件（用于API Key更新后）"""
        self._load_config()

    def get_api_key(self, provider: str) -> Optional[str]:
        """
        获取指定提供者的 API Key。

        优先级：环境变量 > 配置文件

        Args:
            provider: 提供者名称 (deepseek / dashscope / kimi 等)

        Returns:
            API Key 或 None
        """
        # 优先从环境变量
        env_map = {
            "openai": "OPENAI_API_KEY",
            "claude": "ANTHROPIC_API_KEY",
            "kimi": "MOONSHOT_API_KEY",
            "dashscope": "DASHSCOPE_API_KEY",
            "minimax": "MINIMAX_API_KEY",
            "deepseek": "DEEPSEEK_API_KEY",
        }
        env_key = env_map.get(provider.lower())
        if env_key:
            env_value = os.getenv(env_key)
            if env_value:
                return env_value

        # 其次从配置文件 api_keys 节点
        if self._config:
            api_keys = self._config.get("llm", {}).get("api_keys", {})
            return api_keys.get(provider.lower())

        return None

    def get_model(self, provider: str, model_id: str = None) -> Optional[str]:
        """
        获取模型名称。

        Args:
            provider: 提供者名称
            model_id: 模型 ID（可选）

        Returns:
            模型名称
        """
        if self._config:
            providers = self._config.get("llm", {}).get("providers", {})
            provider_config = providers.get(provider.lower(), {})
            models = provider_config.get("models", [])

            if model_id:
                for m in models:
                    if m.get("id") == model_id:
                        return m.get("id")
                return model_id

            if models:
                return models[0].get("id")

        return None

    def get_provider_config(self, provider: str) -> Optional[dict]:
        """获取提供者完整配置"""
        if self._config:
            providers = self._config.get("llm", {}).get("providers", {})
            return providers.get(provider.lower())
        return None


def get_llm_config() -> LLMConfig:
    """获取 LLM 配置单例"""
    return LLMConfig()


def get_api_key(provider: str) -> Optional[str]:
    """快捷方法：获取 API Key"""
    return get_llm_config().get_api_key(provider)