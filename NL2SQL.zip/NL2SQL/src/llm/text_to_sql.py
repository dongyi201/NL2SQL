# -*- coding: utf-8 -*-
"""
LLM Text-to-SQL 核心生成器 —— 基于大模型生成 SQL。
支持规则引擎兜底 + LLM 主生成的双模式。
"""

import os
import json
import re
from typing import Optional

from src.llm.providers import get_provider
from src.llm.schema_formatter import SchemaFormatter
from src.llm.config_loader import get_llm_config
from src.schema.metadata import SchemaManager
from src.dialect.sqlglot_converter import SQLGlotDialectConverter


class LLMTextToSQL:
    """
    基于 LLM 的自然语言转 SQL 生成器。

    支持多种 LLM 提供者：OpenAI GPT / Claude / Kimi / 通义千问
    支持规则引擎兜底模式
    """

    # SQL 方言对应的方言描述
    DIALECT_HINTS = {
        "hive": (
            "使用 HQL（Hive SQL）语法。\n"
            "- 当前日期: CURRENT_DATE\n"
            "- 日期加减: DATE_SUB(CURRENT_DATE, N) / DATE_ADD(CURRENT_DATE, N)\n"
            "- 月份加减: ADD_MONTHS(CURRENT_DATE, -N)\n"
            "- 字符串截取: SUBSTR(col, 1, 10)\n"
            "- 聚合函数: SUM, COUNT, AVG, MAX, MIN, COUNT(DISTINCT ...)"
        ),
        "doris": (
            "使用 Doris SQL 语法（兼容 MySQL）。\n"
            "- 当前日期: CURDATE() 或 CURRENT_DATE()\n"
            "- 日期加减: DATE_SUB(CURDATE(), INTERVAL N DAY)\n"
            "- 月份加减: DATE_SUB(CURDATE(), INTERVAL N MONTH)\n"
            "- 字符串截取: SUBSTRING(col, 1, 10)\n"
            "- 聚合函数: SUM, COUNT, AVG, MAX, MIN\n"
            "- 去重: COUNT(DISTINCT ...)"
        ),
        "starrocks": (
            "使用 StarRocks SQL 语法（兼容 MySQL）。\n"
            "- 当前日期: CURDATE() 或 CURRENT_DATE()\n"
            "- 日期加减: DATE_SUB(CURDATE(), N)\n"
            "- 月份加减: DATE_ADD(CURDATE(), N)\n"
            "- 聚合函数: SUM, COUNT, AVG, MAX, MIN"
        ),
        "flink": (
            "使用 Flink SQL 语法（接近 Hive）。\n"
            "- 当前日期: CURRENT_DATE\n"
            "- 当前时间戳: CURRENT_TIMESTAMP\n"
            "- 日期加减: DATE_SUB(CURRENT_DATE, N)\n"
            "- 聚合函数: SUM, COUNT, AVG, MAX, MIN"
        ),
    }

    def __init__(
        self,
        provider: str = "dashscope",
        model: str = "qwen-turbo",
        api_key: str = None,
        schema_config: str = None,
        use_rule_fallback: bool = True,
        confidence_threshold: float = 0.7,
        **kwargs,
    ):
        """
        初始化 LLM Text-to-SQL 生成器。

        Args:
            provider: LLM 提供者 (openai / claude / kimi / dashscope)
            model: 模型名称
            api_key: API Key（优先从参数读取，其次从环境变量）
            schema_config: 数据字典配置文件路径
            use_rule_fallback: 当 LLM 失败时是否使用规则引擎兜底
            confidence_threshold: 规则引擎置信度阈值（低于此值走 LLM）
            **kwargs: 其他 LLM 配置参数
        """
        self.provider_name = provider
        self.model = model
        self.schema = SchemaManager(schema_config)
        self.schema_formatter = SchemaFormatter(self.schema)
        self.use_rule_fallback = use_rule_fallback
        self.confidence_threshold = confidence_threshold
        self._use_schema = True  # 默认传入 schema

        resolved_key = api_key or self._resolve_api_key(provider)
        self.llm = get_provider(provider, api_key=resolved_key, model=model, **kwargs)

    def _resolve_api_key(self, provider: str) -> Optional[str]:
        """解析 API Key：优先级 1. 环境变量 2. 配置文件"""
        # 方式1：从环境变量获取（优先级最高）
        env_map = {
            "openai": "OPENAI_API_KEY",
            "claude": "ANTHROPIC_API_KEY",
            "kimi": "MOONSHOT_API_KEY",
            "dashscope": "DASHSCOPE_API_KEY",
            "minimax": "MINIMAX_API_KEY",
            "deepseek": "DEEPSEEK_API_KEY",
        }
        env_key = env_map.get(provider.lower())
        env_value = os.getenv(env_key) if env_key else None
        if env_value:
            return env_value

        # 方式2：从配置文件读取
        config = get_llm_config()
        config_key = config.get_api_key(provider)
        if config_key:
            return config_key

        return None

    def convert(
        self,
        text: str,
        dialect: str = "hive",
        force_llm: bool = False,
        temperature: float = 0.1,
        use_schema: bool = True,
    ) -> dict:
        """
        将自然语言转换为 SQL。

        Args:
            text: 用户输入的自然语言
            dialect: 目标 SQL 方言 (hive / doris / starrocks / flink)
            force_llm: 强制使用 LLM（跳过规则引擎）
            temperature: LLM 温度参数（越低越确定性）
            use_schema: 是否传入本地 schema 信息（True=参考模式，False=自由模式）

        Returns:
            dict: {
                "sql": str,           # 生成的 SQL
                "dialect": str,       # 方言
                "confidence": float,  # 置信度 0~1
                "source": str,        # "llm" 或 "rule"
                "elapsed_ms": float, # 耗时（毫秒）
                "error": str,         # 错误信息（如果有）
                "ir": dict,           # 中间表示
            }
        """
        import time

        # 保存 schema 使用设置
        self._use_schema = use_schema

        start = time.perf_counter()

        # Step 1: 规则引擎预检
        ir_result = None
        if not force_llm:
            ir_result = self._try_rule_engine(text)

        # Step 2: 决定使用 LLM 还是规则引擎
        if force_llm or (ir_result is None) or (ir_result.get("confidence", 0) < self.confidence_threshold):
            sql, error = self._generate_by_llm(text, dialect, temperature)
            source = "llm"
            confidence = 0.95 if not error else 0.3
        else:
            sql = ir_result.get("sql", "")
            source = "rule"
            confidence = ir_result.get("confidence", 0.5)
            error = None

        # Step 3: 处理结果
        elapsed = (time.perf_counter() - start) * 1000

        if sql and not error:
            # 清理 LLM 输出的 SQL
            sql = self._clean_sql(sql)

            # Step 4: 使用 sqlglot 验证 SQL 语法正确性
            validator = SQLGlotDialectConverter()
            valid, error_msg, validated_sql = validator.validate(sql, dialect)

            if valid and validated_sql:
                sql = validated_sql
            elif error_msg:
                error = f"SQL 语法验证失败: {error_msg}"

        return {
            "sql": sql or "",
            "dialect": dialect,
            "confidence": confidence,
            "source": source,
            "elapsed_ms": round(elapsed, 2),
            "error": error,
            "ir": ir_result.get("ir") if ir_result else {},
        }

    def _try_rule_engine(self, text: str) -> Optional[dict]:
        """尝试使用规则引擎解析"""
        try:
            from src.entity.extractor import EntityExtractor
            from src.generator.sql_builder import SQLBuilder

            extractor = EntityExtractor(self.schema)
            builder = SQLBuilder(self.schema)

            ir = extractor.extract(text)

            if ir.table and ir.confidence >= 0.4:
                sql = builder.build(ir)
                return {
                    "sql": sql,
                    "confidence": ir.confidence,
                    "ir": {
                        "intent": ir.intent,
                        "table": ir.table,
                        "metrics": ir.metrics,
                        "dimensions": ir.dimensions,
                        "filters": ir.filters,
                    },
                }
        except Exception:
            pass

        return None

    def _generate_by_llm(
        self, text: str, dialect: str, temperature: float
    ) -> tuple[str, Optional[str]]:
        """调用 LLM 生成 SQL"""
        # 根据 use_schema 决定是否传入 schema 信息
        if self._use_schema:
            schema_text = self.schema_formatter.format_for_llm()
        else:
            schema_text = "（未提供，用户需自行推断表名和字段）"

        dialect_hint = self.DIALECT_HINTS.get(dialect, self.DIALECT_HINTS["hive"])

        system_prompt = self._build_system_prompt(schema_text, dialect_hint)
        user_prompt = self._build_user_prompt(text)

        messages = [
            self.llm.system_message(system_prompt),
            self.llm.user_message(user_prompt),
        ]

        try:
            response = self.llm.chat(messages, temperature=temperature)
            sql = self._extract_sql(response)
            return sql, None
        except Exception as e:
            return "", f"LLM调用失败: {str(e)}"

    def _build_system_prompt(self, schema_text: str, dialect_hint: str) -> str:
        # 根据是否有 schema 信息决定提示词
        if self._use_schema and schema_text and "未提供" not in schema_text:
            # 参考模式：有 schema 信息
            schema_section = f"## 可用数据表\n{schema_text}\n"
            constraint = "3. 所有字段、表名使用完整路径（如 dw.dwd_order_info.order_amount）"
        else:
            # 自由模式：没有 schema 信息
            schema_section = ""
            constraint = "3. 根据业务语义自行推断表名和字段名，生成的 SQL 必须可执行"

        return f"""你是一个数据仓库 SQL 专家，擅长将自然语言转换为 SQL 查询。

## 你的职责
1. 根据用户输入的自然语言，理解其数据查询意图
2. 根据业务语义推断合适的表和字段
3. 生成正确、可执行的 SQL 语句

{schema_section}
## SQL 语法要求（{dialect_hint.split(chr(10))[0]}）
{dialect_hint}

## 重要约束
1. 只生成 SELECT 查询语句（不支持 INSERT/UPDATE/DELETE）
2. 生成完整、可直接执行的 SQL，不使用占位符
{constraint}
4. 如果自然语言中没有指定时间范围，不要添加时间过滤条件
5. 字段别名使用中文（如 SELECT SUM(amount) AS `销售额`）
6. 如果无法确定 JOIN 条件，优先使用单表查询

## 输出格式
直接输出 SQL 语句，不要任何解释，不要 markdown 代码块。
"""

    def _build_user_prompt(self, text: str) -> str:
        return f"用户: {text}\n\nSQL:"

    def _extract_sql(self, response: str) -> str:
        """从 LLM 输出中提取 SQL 语句"""
        sql = response.strip()

        if not sql:
            return ""

        # 去掉可能的 markdown 代码块
        if sql.startswith("```"):
            parts = sql.split("```")
            for part in parts:
                part = part.strip()
                if part.upper().startswith("SQL"):
                    part = part[3:].strip()
                if "SELECT" in part.upper():
                    sql = part
                    break
            else:
                sql = parts[-1].strip() if len(parts) > 1 else sql

        # 去掉 SQL 前的非 SQL 内容（如 "以下是SQL："）
        sql = re.sub(r"^(SQL(?:语句)?:?)\s*", "", sql, flags=re.IGNORECASE)

        # 去掉首行的非 SELECT 内容
        lines = sql.split("\n")
        cleaned_lines = []
        for line in lines:
            if cleaned_lines or line.strip().upper().startswith("SELECT"):
                cleaned_lines.append(line)
        sql = "\n".join(cleaned_lines) if cleaned_lines else sql

        return sql.strip()

    def _clean_sql(self, sql: str) -> str:
        """清理 SQL，移除注释和多余空白"""
        lines = []
        for line in sql.split("\n"):
            line = line.strip()
            if line and not line.startswith("--"):
                lines.append(line)
        return "\n".join(lines)