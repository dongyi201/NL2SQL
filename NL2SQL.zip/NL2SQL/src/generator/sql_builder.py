# -*- coding: utf-8 -*-
"""
SQL 生成器 —— 将实体抽取结果（IR）拼装成标准 SQL 语句。
这是 NL2SQL 的核心：IR → SQL。
"""

from src.entity.extractor import EntityResult
from src.schema.metadata import SchemaManager


class SQLBuilder:
    def __init__(self, schema: SchemaManager):
        self.schema = schema

    def build(self, ir: EntityResult) -> str:
        if ir.intent != "SELECT":
            return f"-- 暂不支持 {ir.intent} 操作"

        if not ir.table:
            return "-- 未识别到数据表，请明确要查询哪张表"

        table = ir.table
        alias = ir.table_alias or table.split(".")[-1]

        select_clause = self._build_select(ir, alias)
        from_clause = self._build_from(table, alias)
        where_clause = self._build_where(ir, alias)
        group_clause = self._build_group_by(ir, alias)
        order_clause = self._build_order_by(ir, alias)
        limit_clause = self._build_limit(ir)

        parts = [select_clause, from_clause]
        if where_clause:
            parts.append(where_clause)
        if group_clause:
            parts.append(group_clause)
        if order_clause:
            parts.append(order_clause)
        if limit_clause:
            parts.append(limit_clause)

        return "\n".join(parts)

    def _build_select(self, ir: EntityResult, alias: str) -> str:
        select_fields = []

        # 维度字段
        if ir.dimensions:
            for dim in ir.dimensions:
                short = dim.split(".")[-1]
                select_fields.append(f"  {alias}.{short} AS `{short}`")

        # 指标字段
        if ir.metrics:
            for m in ir.metrics:
                expr = self._adapt_expression(m["expression"], alias)
                select_fields.append(f"  {expr} AS `{m['alias']}`")

        if not select_fields:
            # 兜底：SELECT *
            select_fields = [f"  {alias}.*"]

        return "SELECT\n" + ",\n".join(select_fields)

    def _build_from(self, table: str, alias: str) -> str:
        return f"FROM {table} AS {alias}"

    def _build_where(self, ir: EntityResult, alias: str) -> str:
        conditions = []

        for f in ir.filters:
            field_short = f["field"].split(".")[-1]
            value = f["value"]
            if isinstance(value, str) and not value.startswith(
                "DATE_SUB"
            ) and not value.startswith("CURRENT"):
                escaped = (
                    f"'{value}'"
                    if not (value.startswith("'") and value.endswith("'"))
                    else value
                )
            else:
                escaped = str(value)
            conditions.append(
                f"  {alias}.{field_short} {f['op']} {escaped}"
            )

        if not conditions:
            return ""
        return "WHERE\n" + "\nAND ".join(conditions)

    def _build_group_by(self, ir: EntityResult, alias: str) -> str:
        if ir.dimensions:
            groups = []
            for dim in ir.dimensions:
                short = dim.split(".")[-1]
                groups.append(f"  {alias}.{short}")
            return "GROUP BY\n" + ",\n".join(groups)
        return ""

    def _build_order_by(self, ir: EntityResult, alias: str) -> str:
        """如果有指标则按指标降序，否则按第一个维度排序。"""
        if ir.metrics:
            first_metric = ir.metrics[0]
            field_name = first_metric["alias"]
            return f"ORDER BY\n  `{field_name}` DESC"
        if ir.dimensions:
            first_dim = ir.dimensions[0].split(".")[-1]
            return f"ORDER BY\n  {alias}.{first_dim}"
        return ""

    def _build_limit(self, ir: EntityResult) -> str:
        if ir.limit:
            return f"LIMIT {ir.limit}"
        return ""

    def _adapt_expression(self, expr: str, alias: str) -> str:
        """把指标表达式里的表名替换成别名。"""
        if expr.upper().startswith("COUNT") or expr.upper().startswith(
            "SUM"
        ) or expr.upper().startswith("AVG"):
            # 提取表名部分替换成 alias
            import re

            m = re.search(
                r"(COUNT|SUM|AVG|MAX|MIN)\s*\(\s*(DISTINCT\s+)?(.+?)\)",
                expr,
                re.IGNORECASE,
            )
            if m:
                func = m.group(1).upper()
                distinct = m.group(2) or ""
                col_ref = m.group(3).strip()
                short = col_ref.split(".")[-1] if "." in col_ref else col_ref
                if distinct.strip():
                    return f"{func}({distinct}{alias}.{short})"
                return f"{func}({alias}.{short})"
        return expr
