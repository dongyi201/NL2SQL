# -*- coding: utf-8 -*-
"""
数据字典模块 —— 加载 YAML 配置，提供字段查询、同义词解析、关联发现。
这是整个 NL2SQL 系统的"知识库"。
"""

import os
import yaml
from typing import Optional


_SUPPORTED_TIME_COLS = {"create_time", "pay_time", "register_date", "update_time"}


class ColumnInfo:
    def __init__(self, col_dict: dict, table_name: str):
        self.name = col_dict["name"]
        self.chinese_name = col_dict.get("chinese_name", self.name)
        self.type = col_dict.get("type", "STRING")
        self.aliases = col_dict.get("aliases", [])
        self.enum_values = col_dict.get("enum_values", [])
        self.table_name = table_name
        self.is_time = self.name in _SUPPORTED_TIME_COLS

    @property
    def full_path(self):
        return f"{self.table_name}.{self.name}"

    def match(self, word: str) -> bool:
        w = word.lower()
        return (
            w == self.name.lower()
            or w == self.chinese_name
            or any(w == alias for alias in self.aliases)
        )

    def enum_lookup(self, word: str) -> Optional[str]:
        """同义词 → 标准值映射  e.g.  '华北' → '北京'"""
        if isinstance(self.enum_values, dict):
            return self.enum_values.get(word)
        return None

    def __repr__(self):
        return f"Column({self.full_path})"


class TableInfo:
    def __init__(self, table_dict: dict):
        self.name = table_dict["name"]
        self.chinese_name = table_dict.get("chinese_name", self.name)
        self.description = table_dict.get("description", "")
        self.aliases = table_dict.get("aliases", [])
        self.columns = [
            ColumnInfo(c, self.name) for c in table_dict.get("columns", [])
        ]

    def match(self, word: str) -> bool:
        w = word.lower()
        return (
            w == self.name.lower()
            or w == self.chinese_name
            or any(w == alias for alias in self.aliases)
        )

    def find_column(self, word: str) -> Optional[ColumnInfo]:
        for col in self.columns:
            if col.match(word):
                return col
        return None

    def __repr__(self):
        return f"Table({self.name})"


class SchemaManager:
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = os.path.join(
                os.path.dirname(__file__), "..", "..", "config", "schema.yaml"
            )
        config_path = os.path.abspath(config_path)
        with open(config_path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)

        self.tables: list[TableInfo] = [
            TableInfo(t) for t in raw.get("tables", [])
        ]
        self.synonym_map: dict[str, str] = raw.get("synonym_map", {})
        self.relations: list[dict] = raw.get("relations", [])

        self._build_index()

    def _build_index(self):
        self._all_columns: list[ColumnInfo] = []
        for t in self.tables:
            self._all_columns.extend(t.columns)

    def find_table(self, word: str) -> Optional[TableInfo]:
        for t in self.tables:
            if t.match(word):
                return t
        return None

    def find_column_globally(self, word: str) -> Optional[ColumnInfo]:
        """在所有表的字段里查找匹配"""
        # 先查同义词
        if word in self.synonym_map:
            expr = self.synonym_map[word]
            for col in self._all_columns:
                if expr == col.name:
                    return col
            return None
        for col in self._all_columns:
            if col.match(word):
                return col
        return None

    def resolve_metric(self, word: str) -> Optional[str]:
        """把'销售额' → 'SUM(order_amount)' 这样的指标表达式"""
        if word in self.synonym_map:
            expr = self.synonym_map[word]
            if expr.upper().startswith("COUNT") or expr.upper().startswith(
                "SUM"
            ):
                return expr  # 已经是完整表达式
            return f"SUM({expr})"
        col = self.find_column_globally(word)
        if col:
            return f"SUM({col.full_path})"
        return None

    def resolve_dimension(self, word: str) -> Optional[str]:
        """把'地区' → 'dw.dwd_order_info.region'"""
        col = self.find_column_globally(word)
        if col:
            return col.full_path
        return None

    def find_related_tables(self, table_name: str) -> list[dict]:
        """找到与指定表有 JOIN 关系的其他表"""
        related = []
        for rel in self.relations:
            if rel["left_table"] == table_name:
                related.append(rel)
            elif rel["right_table"] == table_name:
                related.append(rel)
        return related

    def resolve_enum_value(
        self, col: ColumnInfo, word: str
    ) -> Optional[str]:
        """将枚举别名转成真实值  e.g. '华北' → '北京'"""
        return col.enum_lookup(word)
