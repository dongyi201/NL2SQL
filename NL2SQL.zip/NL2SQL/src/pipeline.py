# -*- coding: utf-8 -*-
"""
NL2SQL 主流程 —— 串联各个模块，实现 自然语言 → SQL 的完整链路。
"""

from dataclasses import dataclass
from typing import Optional

from src.schema.metadata import SchemaManager
from src.entity.extractor import EntityExtractor
from src.generator.sql_builder import SQLBuilder
from src.dialect.hive import HiveDialect
from src.dialect.doris import DorisDialect
from src.dialect.starrocks import StarRocksDialect
from src.dialect.flink import FlinkDialect

_DIALECTS = {
    "hive": HiveDialect(),
    "doris": DorisDialect(),
    "starrocks": StarRocksDialect(),
    "flink": FlinkDialect(),
}


@dataclass
class NL2SQLResult:
    raw_text: str
    dialect: str
    sql: str
    ir: dict
    confidence: float
    elapsed_ms: float


class NL2SQLPipeline:
    def __init__(self, schema_config_path: Optional[str] = None):
        self.schema = SchemaManager(schema_config_path)
        self.extractor = EntityExtractor(self.schema)
        self.builder = SQLBuilder(self.schema)

    def convert(
        self, text: str, dialect: str = "hive"
    ) -> NL2SQLResult:
        import time

        start = time.perf_counter()

        ir = self.extractor.extract(text)

        sql = self.builder.build(ir)

        converter = _DIALECTS.get(dialect)
        if converter:
            sql = converter.convert(sql)
        else:
            sql = f"-- unknown dialect '{dialect}', using standard SQL\n{sql}"

        elapsed = (time.perf_counter() - start) * 1000

        return NL2SQLResult(
            raw_text=text,
            dialect=dialect,
            sql=sql,
            ir={
                "intent": ir.intent,
                "table": ir.table,
                "metrics": ir.metrics,
                "dimensions": ir.dimensions,
                "filters": ir.filters,
            },
            confidence=ir.confidence,
            elapsed_ms=round(elapsed, 2),
        )

    def convert_all_dialects(
        self, text: str
    ) -> dict[str, NL2SQLResult]:
        """一次性输出所有方言的 SQL。"""
        results = {}
        for name in _DIALECTS:
            results[name] = self.convert(text, name)
        return results
